-- phpMyAdmin SQL Dump
-- version 4.6.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: May 03, 2024 at 03:09 PM
-- Server version: 5.5.50
-- PHP Version: 5.5.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project_school_portal`
--

-- --------------------------------------------------------

--
-- Table structure for table `accounts`
--

CREATE TABLE `accounts` (
  `id` int(10) NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `accounts`
--

INSERT INTO `accounts` (`id`, `username`, `password`, `email`) VALUES
(1, 'admin', 'onuorah12', 'benjamin.onuorah@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `assignment_submission`
--

CREATE TABLE `assignment_submission` (
  `submit_id` int(20) NOT NULL,
  `expected_score` varchar(100) NOT NULL,
  `teacher_score` varchar(100) NOT NULL,
  `user_id` varchar(50) NOT NULL,
  `user_type` varchar(50) NOT NULL,
  `lesson_id` varchar(50) NOT NULL,
  `your_answer` text NOT NULL,
  `your_upload` varchar(255) NOT NULL,
  `date_submitted` varchar(50) NOT NULL,
  `teacher_note` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `assignment_submission`
--

INSERT INTO `assignment_submission` (`submit_id`, `expected_score`, `teacher_score`, `user_id`, `user_type`, `lesson_id`, `your_answer`, `your_upload`, `date_submitted`, `teacher_note`) VALUES
(8, '100', '', '1', 'admin', '4', 'fdfdf', '', '2024-05-02 10:56:33.469849', ''),
(9, '100', '100', '1', 'admin', '2', 'fdgfdgdfgdfgdfgdfgfd\r\ngdfgdf\r\ngdfgdfg', '', '2024-05-02 12:00:11.068370', 'dd'),
(10, '100', '', '1', 'admin', '1', 'OBJECTIVE  \r\nYour cooperative society need a professional software application to store and manage your transaction record as your record grows and data operation and retrieval becomes more complex and difficult with Microsoft excel spreadsheet.  \r\n\r\nOUR SOLUTION\r\nCooperative Savings and Loan Software (CSLS) is a customized software we would develop for your organization, we will work closely with your personnel to understand your operations and how you have been storing, organizing  and managing your record using  Microsoft excel spreadsheet. This knowledge will help us to design and develop a custom software that will meet your specific need.\r\n\r\nThe software is going to be a web based software that will be hosted online so that every member of the cooperative can login to access their saving details, loan and other financial records.\r\n\r\nThe software will use a database to store all record in a well structure design and format and a back-end programming language to simplify your task and make it easy for you to access your information.\r\n\r\nProject work-flow and development stages\r\nIn accord with the scope of the project and the client\'s wishes. All projects include the stages described below.\r\n\r\nProposal and approval\r\nUpon receiving your request, we provide you with a proposal with the project cost and work-flow and we got an approval to initiate the project with a weekly progress report and testing.\r\n\r\nThree-month bug-free warranty\r\nOnce the final the project have been finally delivered to you, your 6-month development warranty begins. During this period we fix bugs - if there are any - in our code, at no charge to you. We have a high degree of confidence in our testing/quality assurance processes. That is why we offer such a unique extended development warranty to all our clients.', '2024-05-03_083816.638495Ben_Onuorah_Ndu_Uwa_Life.jpg', '2024-05-03 08:38:16.638435', '');

-- --------------------------------------------------------

--
-- Table structure for table `class_tb`
--

CREATE TABLE `class_tb` (
  `id` int(10) NOT NULL,
  `class_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `class_tb`
--

INSERT INTO `class_tb` (`id`, `class_name`) VALUES
(1, 'Basic 1'),
(2, 'Basic 2'),
(3, 'Basic 3'),
(4, 'JSS 1');

-- --------------------------------------------------------

--
-- Table structure for table `lesson_assignment`
--

CREATE TABLE `lesson_assignment` (
  `assignment_id` int(20) NOT NULL,
  `lesson_id` varchar(50) NOT NULL,
  `assignment_title` varchar(255) NOT NULL,
  `detail` text NOT NULL,
  `max_score` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lesson_assignment`
--

INSERT INTO `lesson_assignment` (`assignment_id`, `lesson_id`, `assignment_title`, `detail`, `max_score`) VALUES
(1, '1', 'Maths assignment 1b', 'Here is the assignment here...', '100'),
(5, '5', 'tessss', 'sdsds', '100'),
(9, '2', 'Assignment on history of Nigeria', 'This Service Level Agreement (SLA) is entered into by and between BICL (referred to as "Service Provider") and LASAA Staff Cooperative Society  (referred to as "Client") on this date 11 July 2023.\r\n    1. Service Overview\r\n1.1. Scope: This SLA defines the terms and conditions under which the Service Provider will deliver Cooperative Savings and Loan Software (CSLS) to the Client.\r\n1.2. Objective: The objective of this SLA is to ensure that the CSLS services provided by the Service Provider meet the agreed-upon performance standards and levels of support.\r\n    2. Service Description\r\n2.1. Cooperative Savings and Loan Software (CSLS) is a customized software we would develop for your organization, we will work closely with your personnel to understand your operations and how you have been storing, organizing  and managing your record using  Microsoft excel spreadsheet. This knowledge will help us to design and develop a custom software that will meet your specific need.\r\nThe software is going to be a web based software that will be hosted online so that every member of the cooperative can login to access their saving details, loan and other financial records.\r\n\r\nThe software will use a database to store all record in a well structure design and format and a back-end programming language to simplify your task and make it easy for you to access your information.\r\n    3. Service Levels\r\nProject work-flow and development stages\r\nIn accord with the scope of the project and the client\'s wishes. All projects include the stages described below.\r\n\r\nProposal and approval\r\nUpon receiving your request, we provide you with a proposal with the project cost and work-flow and we got an approval to initiate the project with a weekly progress report and testing.\r\n\r\nThree-month bug-free warranty\r\nOnce the final the project have been finally delivered to you, your 6-month development warranty begins. During this period we fix bugs - if there are any - in our code, at no charge to you. We have a high degree of confidence in our testing/quality assurance processes. That is why we offer such a unique extended development warranty to all our clients.\r\n', '100'),
(10, '4', 'Sumultaneous equation', 'submit_id\r\nexpected_score\r\nyour_score\r\nuser_id\r\nuser_type\r\nlesson_id\r\nyour_answer\r\ndate_submitted\r\n\r\nSolve this', '100');

-- --------------------------------------------------------

--
-- Table structure for table `lesson_td`
--

CREATE TABLE `lesson_td` (
  `lesson_id` int(10) NOT NULL,
  `lesson_title` varchar(255) NOT NULL,
  `lesson_detail` text NOT NULL,
  `subject` varchar(100) NOT NULL,
  `class_id` varchar(100) NOT NULL,
  `term` varchar(100) NOT NULL,
  `week` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lesson_td`
--

INSERT INTO `lesson_td` (`lesson_id`, `lesson_title`, `lesson_detail`, `subject`, `class_id`, `term`, `week`) VALUES
(1, 'Maths topic 1', 'rere', '6', '1', '1', '4'),
(2, 'History of Nigeria', 'SERVICE LEVEL AGREEMENT (SLA) FOR WEB APPLICATION PROJECT\r\n\r\nThis Service Level Agreement (SLA) is entered into by and between BICL (referred to as "Service Provider") and LASAA Staff Cooperative Society  (referred to as "Client") on this date 11 July 2023.\r\n    1. Service Overview\r\n1.1. Scope: This SLA defines the terms and conditions under which the Service Provider will deliver Cooperative Savings and Loan Software (CSLS) to the Client.\r\n1.2. Objective: The objective of this SLA is to ensure that the CSLS services provided by the Service Provider meet the agreed-upon performance standards and levels of support.', '4', '1', '2', '9'),
(3, 'Intro to Grammar', 'sdsdsdsdsdsd\r\nsdsdsdsd', '3', '2', '2', '2'),
(4, 'Maths topic 2', 'Here is the details here....', '6', '1', '2', '1'),
(5, 'Maths topic 3', '', '6', '1', '3', '1'),
(6, 'Intro to maths', 'dsdsdss', '6', '1', '1', '1'),
(7, 'History of Nigeria part 2', 'SERVICE LEVEL AGREEMENT (SLA) FOR WEB APPLICATION PROJECT\r\n\r\nThis Service Level Agreement (SLA) is entered into by and between BICL (referred to as "Service Provider") and LASAA Staff Cooperative Society  (referred to as "Client") on this date 11 July 2023.\r\n    1. Service Overview\r\n1.1. Scope: This SLA defines the terms and conditions under which the Service Provider will deliver Cooperative Savings and Loan Software (CSLS) to the Client.\r\n1.2. Objective: The objective of this SLA is to ensure that the CSLS services provided by the Service Provider meet the agreed-upon performance standards and levels of support.\r\n    2. Service Description\r\n2.1. Cooperative Savings and Loan Software (CSLS) is a customized software we would develop for your organization, we will work closely with your personnel to understand your operations and how you have been storing, organizing  and managing your record using  Microsoft excel spreadsheet. This knowledge will help us to design and develop a custom software that will meet your specific need.\r\nThe software is going to be a web based software that will be hosted online so that every member of the cooperative can login to access their saving details, loan and other financial records.\r\n\r\nThe software will use a database to store all record in a well structure design and format and a back-end programming language to simplify your task and make it easy for you to access your information.\r\n    3. Service Levels\r\nProject work-flow and development stages\r\nIn accord with the scope of the project and the client\'s wishes. All projects include the stages described below.\r\n\r\nProposal and approval\r\nUpon receiving your request, we provide you with a proposal with the project cost and work-flow and we got an approval to initiate the project with a weekly progress report and testing.\r\n\r\nThree-month bug-free warranty\r\nOnce the final the project have been finally delivered to you, your 6-month development warranty begins. During this period we fix bugs - if there are any - in our code, at no charge to you. We have a high degree of confidence in our testing/quality assurance processes. That is why we offer such a unique extended development warranty to all our clients.\r\n\r\nPost-warranty period / professional support\r\nIf the client wants to implement an additional functionality, after the project is launched, we treat such requests as separate projects. If the client wants to implement small changes directly on the site, that can usually be done under our support service at a minimal cost starting from 5000 naira.\r\n\r\nCode Quality / Quality Assurance\r\nWe have an internal quality assurance process. This means that all code we develop is validated according to the latest standards and best practices of web development.\r\nWe delivers stable high-quality development products that are tested and built according to Software development best practices in performance, security and user interface (UI).\r\n\r\nHosting and back-up\r\nWe host our client web project on a secure hosting server with HTTPS support and does a monthly database backup and no cost.\r\n\r\n    4. Client Responsibilities\r\n4.1. Cooperation: The Client will cooperate with the Service Provider in providing necessary information, access, and resources required for the successful delivery of the web application services.\r\n4.2. Reporting Issues: The Client will promptly report any issues or bugs related to the web application to the Service Provider, including providing detailed information and steps to reproduce the problem.\r\n    5. Exclusions\r\n5.1. Third-Party Services: This SLA does not cover any issues or disruptions caused by third-party services or applications integrated with the web application.\r\n5.2. Force Majeure: The Service Provider shall not be held liable for any delays, disruptions, or failures caused by events beyond their reasonable control, including but not limited to natural disasters, acts of terrorism, or government regulations.\r\n    6. Term and Termination\r\n6.1. Term: This SLA will be effective from the date of signing and will remain in effect for the duration specified in the project proposal.\r\n6.2. Termination: Either party may terminate this SLA in the event of a material breach by the other party, subject to providing a written notice of the breach and a reasonable opportunity to cure it.\r\n    7. Confidentiality', '4', '1', '2', '1');

-- --------------------------------------------------------

--
-- Table structure for table `lesson_upload_td`
--

CREATE TABLE `lesson_upload_td` (
  `upload_id` int(10) NOT NULL,
  `lesson_id` varchar(50) NOT NULL,
  `caption` varchar(255) NOT NULL,
  `youtube_video` varchar(255) NOT NULL,
  `image_file` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lesson_upload_td`
--

INSERT INTO `lesson_upload_td` (`upload_id`, `lesson_id`, `caption`, `youtube_video`, `image_file`) VALUES
(1, '1', '', 'eee', '2024-04-30_140020.339477IMG-20240420-WA0014.jpg'),
(2, '1', '', 'https://www.youtube.com/embed/OLH9Wy-wI9E', ''),
(3, '1', '', '', '2024-04-30_145627.701501WhatsApp_Image_2024-04-19_at_1.00.48_PM_2.jpeg'),
(4, '5', '', '', '2024-05-01_121236.237918Screenshot_2024-04-29_at_12-27-41_School_Portal.png'),
(5, '2', 'none', 'https://www.youtube.com/embed/OLH9Wy-wI9E', '2024-05-01_162430.700498Screenshot_2024-04-18_at_14-20-20_Educational_Perspectives.png'),
(6, '2', '', '', '2024-05-01_162502.690355Screenshot_2023-11-06_at_23-40-24_home_MediPalHealthCare.png');

-- --------------------------------------------------------

--
-- Table structure for table `student_tb`
--

CREATE TABLE `student_tb` (
  `student_id` int(10) NOT NULL,
  `surname` varchar(255) NOT NULL,
  `other_names` varchar(255) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `date_of_birth` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `class` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `date_reg` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_tb`
--

INSERT INTO `student_tb` (`student_id`, `surname`, `other_names`, `gender`, `date_of_birth`, `email`, `phone`, `class`, `password`, `date_reg`, `status`) VALUES
(2, 'fff', 'ggg', 'Male', '2024-04-29', 'kike@kike.com', '090', '2', 'ddd', '2024-04-29 08:35:03.964541', ''),
(3, 'chioma', 'ola', 'Male', '2024-05-03', 'chioma@mail.com', '', '1', 'chioma', '2024-05-03 17:40:17.225690', '');

-- --------------------------------------------------------

--
-- Table structure for table `subjects_tb`
--

CREATE TABLE `subjects_tb` (
  `subject_id` int(10) NOT NULL,
  `subject_name` varchar(255) NOT NULL,
  `class_id` varchar(50) NOT NULL,
  `term` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subjects_tb`
--

INSERT INTO `subjects_tb` (`subject_id`, `subject_name`, `class_id`, `term`) VALUES
(1, 'Maths', '2', '3'),
(3, 'English', '2', '1'),
(4, 'History', '1', '1'),
(5, 'Maths', '3', '1'),
(6, 'Maths', '1', '1');

-- --------------------------------------------------------

--
-- Table structure for table `teacher_tb`
--

CREATE TABLE `teacher_tb` (
  `teacher_id` int(10) NOT NULL,
  `surname` varchar(255) NOT NULL,
  `other_names` varchar(255) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `date_of_birth` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `subject` varchar(50) NOT NULL,
  `class_id` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `date_reg` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `teacher_tb`
--

INSERT INTO `teacher_tb` (`teacher_id`, `surname`, `other_names`, `gender`, `date_of_birth`, `email`, `phone`, `subject`, `class_id`, `password`, `date_reg`, `status`) VALUES
(2, 'Yemi', 'Olamide', 'Male', '2024-05-01', 'yemi@mail.com', '080676767676', '6', '1', 'yemi', '2024-05-01 08:22:36.226199', ''),
(3, 'Femi', 'rtrt', 'Male', '2024-05-01', 'femi@test.com', '', '4', '1', 'femi', '2024-05-01 08:27:20.498778', ''),
(4, 'Onu', 'Titi', 'Female', '2024-05-01', 'onu@mail.com', '07777777', '5', '3', 'onu', '2024-05-01 08:36:28.461661', ''),
(5, 'Adewale', 'Koka', 'Male', '', 'adeee@mail.com', '', '1', '2', 'addddd', '2024-05-03 06:49:19.881769', ''),
(6, 'sdfsdfdsfsdfs', 'dfsdfs', 'Male', '', 'dfdfdfdfd@ss.com', '', '1', '2', 'dfdfdfdfdfd', '2024-05-03 06:53:32.428670', '');

-- --------------------------------------------------------

--
-- Table structure for table `terms_tb`
--

CREATE TABLE `terms_tb` (
  `id` int(10) NOT NULL,
  `term` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `terms_tb`
--

INSERT INTO `terms_tb` (`id`, `term`) VALUES
(1, '1st Term'),
(2, '2nd Term'),
(3, '3rd Term');

-- --------------------------------------------------------

--
-- Table structure for table `week_tb`
--

CREATE TABLE `week_tb` (
  `id` int(10) NOT NULL,
  `week_num` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `week_tb`
--

INSERT INTO `week_tb` (`id`, `week_num`) VALUES
(1, '1'),
(2, '2'),
(3, '3'),
(4, '4'),
(5, '5'),
(6, '6'),
(7, '7'),
(8, '8'),
(9, '9'),
(10, '10');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accounts`
--
ALTER TABLE `accounts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `assignment_submission`
--
ALTER TABLE `assignment_submission`
  ADD PRIMARY KEY (`submit_id`);

--
-- Indexes for table `class_tb`
--
ALTER TABLE `class_tb`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lesson_assignment`
--
ALTER TABLE `lesson_assignment`
  ADD PRIMARY KEY (`assignment_id`);

--
-- Indexes for table `lesson_td`
--
ALTER TABLE `lesson_td`
  ADD PRIMARY KEY (`lesson_id`);

--
-- Indexes for table `lesson_upload_td`
--
ALTER TABLE `lesson_upload_td`
  ADD PRIMARY KEY (`upload_id`);

--
-- Indexes for table `student_tb`
--
ALTER TABLE `student_tb`
  ADD PRIMARY KEY (`student_id`);

--
-- Indexes for table `subjects_tb`
--
ALTER TABLE `subjects_tb`
  ADD PRIMARY KEY (`subject_id`);

--
-- Indexes for table `teacher_tb`
--
ALTER TABLE `teacher_tb`
  ADD PRIMARY KEY (`teacher_id`);

--
-- Indexes for table `terms_tb`
--
ALTER TABLE `terms_tb`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `week_tb`
--
ALTER TABLE `week_tb`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accounts`
--
ALTER TABLE `accounts`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `assignment_submission`
--
ALTER TABLE `assignment_submission`
  MODIFY `submit_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `class_tb`
--
ALTER TABLE `class_tb`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `lesson_assignment`
--
ALTER TABLE `lesson_assignment`
  MODIFY `assignment_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `lesson_td`
--
ALTER TABLE `lesson_td`
  MODIFY `lesson_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `lesson_upload_td`
--
ALTER TABLE `lesson_upload_td`
  MODIFY `upload_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `student_tb`
--
ALTER TABLE `student_tb`
  MODIFY `student_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `subjects_tb`
--
ALTER TABLE `subjects_tb`
  MODIFY `subject_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `teacher_tb`
--
ALTER TABLE `teacher_tb`
  MODIFY `teacher_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `terms_tb`
--
ALTER TABLE `terms_tb`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `week_tb`
--
ALTER TABLE `week_tb`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
