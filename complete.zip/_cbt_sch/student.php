<?php include("banner.php"); ?>

    <div class="page-content">
    	<div class="row">
		 
		  <div class="col-md-12">
          
          
           <div class="content-box-large">
		   <a href="index.php">Go Back</a>
					<br/>
			  <div class="panel-heading">
					<div class="panel-title">					
                    REGISTER TO TAKE A TEST
                    </div>					
			  </div>
  				<div class="panel-body">
<form action="student2.php" method="post" enctype="multipart/form-data" name="form1" id="form1" class="form-horizontal" >
<?php
if(isset($_GET['msg'])){
	print "<font color=\"#0000FF\">".$_GET['msg']."</font>";
}
if(isset($_GET['err_msg'])){
	print "<font color=\"#FF0000\">".$_GET['err_msg']."</font>";
}

?>


<div class="form-group">
	<label class="col-sm-2 control-label">Password * </label>
    <div class="col-sm-5">	
    	<input name="pw" type="password" class="form-control" required/>      
	</div>
</div>

<div class="form-group">
	<label class="col-sm-2 control-label">Surname * </label>
    <div class="col-sm-5">	
    	<input name="fname" type="text" id="fname" class="form-control" required/>      
	</div>
</div>			          


<div class="form-group">
	<label class="col-sm-2 control-label">Other names </label>
    <div class="col-sm-5">	
    	<input name="other_name" type="text" id="other_name" class="form-control" />      
	</div>
</div>		
  				         
                          
<div class="form-group">
	<label class="col-sm-2 control-label">Gender </label>
    <div class="col-sm-5">	
			<select name="gender" id="gender" class="form-control">
  				<option>Male</option>
                <option>Female</option>
			</select>
    </div>
</div>   


<div class="form-group">
	<label class="col-sm-2 control-label">Date of Birth </label>
    <div class="col-sm-5">	
    	<input name="dob" type="text" id="dob" class="form-control" />      
	</div>
</div>

<div class="form-group">
	<label class="col-sm-2 control-label">Email </label>
    <div class="col-sm-5">	
    	<input name="email" type="text" id="email" class="form-control" />      
	</div>
</div>





<div class="form-group">
	<label class="col-sm-2 control-label">Other details </label>
    <div class="col-sm-5">		
       <textarea class="form-control" name="class"></textarea>         
	</div>
</div>	


<div class="form-group">
	<div class="col-sm-offset-2 col-sm-10">
	Note: you will login using your Email and Password
	<br/>
	<button type="submit" class="btn btn-primary">Submit</button>
   
	</div>
</div>   
        
</form>
  				  </p>
             </div>
  			</div>
		  </div>
		</div>
    </div>

       
    <?php include("../footer.php"); ?>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://code.jquery.com/jquery.js"></script>
    <!-- jQuery UI -->
    <script src="https://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="../bootstrap/js/bootstrap.min.js"></script>

    <link rel="stylesheet" href="../vendors/morris/morris.css">


    <script src="../vendors/jquery.knob.js"></script>
    <script src="../vendors/raphael-min.js"></script>
    <script src="../vendors/morris/morris.min.js"></script>

    <script src="../vendors/flot/jquery.flot.js"></script>
    <script src="../vendors/flot/jquery.flot.categories.js"></script>
    <script src="../vendors/flot/jquery.flot.pie.js"></script>
    <script src="../vendors/flot/jquery.flot.time.js"></script>
    <script src="../vendors/flot/jquery.flot.stack.js"></script>
    <script src="../vendors/flot/jquery.flot.resize.js"></script>

    <script src="../js/custom.js"></script>
    <script src="../js/stats.js"></script>
  </body>
</html>