<?php
include("banner_conn.php");

if(isset($_REQUEST['submit'])){
	$u_id = mysqli_escape_string($conn, $_REQUEST['user_name']);
	$u_pw = mysqli_escape_string($conn, $_REQUEST['password']);
	$user_type = mysqli_escape_string($conn, $_REQUEST['user_type']);
	
	if($user_type=="1"){ //admin		
		include("_tuto_test/test_teacher.php");
	}elseif($user_type=="2"){ //student/candidate
	
	
		$sql = "SELECT * FROM student_tb WHERE email = '$u_id' AND password = '$u_pw'";
					$result = mysqli_query($conn, $sql) or die(mysqli_error());
					
					//get the number of rows in the result set; should be 1 if a match
					if (mysqli_num_rows($result) > 0) {
						$info = mysqli_fetch_array($result);
							$id = $info['student_id'];							
							$first_name = $info['surname'];
							$other_name = $info['other_names'];
							$reg_no = $info['reg_no'];
							//$piks = $info['piks'];
							
							
								$s_n = "";
									session_start();
									$_SESSION['reg_no']=$reg_no;
									$_SESSION['student_id']=$id;
									
									$_SESSION['first_name']=$first_name;
									$_SESSION['other_name']=$other_name;
									
									$_SESSION['class_subject']=$class_subject;
								
									$_SESSION['s_n']=$s_n;	
															
									$_SESSION['type']="student";
									
													header("Location:_stud_test/home_student.php");
													
									
						
						}else {
										print "
										<br>
										<br>
										<br>
										<br>
										Sorry: either the User ID or Password, you provide is incorrect. 
										<p>
										<a href=\"../index.php\">Click here to try again</a>
										";
						}
	
	
	
		
	}
}
	

?>