<footer>
         <div class="container">
         
            <div class="copy text-center">
EduSystems Copyright (c) <?php print date('Y'); ?>
            
            </div>
            
         </div>
      </footer>