<style type="text/css">
<!--
.style5 {font-size: 16px}
-->
</style>
<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td height="19" valign="top">  
	<div align="center">CBT <?php print date('Y'); ?></div></td>
  </tr>
</table>
