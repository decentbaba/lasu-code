<?php
$sel_id = mysqli_real_escape_string($conn, $_GET['id']);


$sql = "SELECT * FROM j_nems_post WHERE com_id = '$_SESSION[id]' AND id='$sel_id'";

$result = mysqli_query($conn, $sql) or die(mysqli_error());
$info = mysqli_fetch_array($result);
$post_id=$info['id'];
$post_name=$info['post_name'];
//$post_name = strtoupper($post_name2);

?>