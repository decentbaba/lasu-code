<?php include("banner1.php"); ?>
				  
				  
    <div class="page-content">
    	<div class="row">
		  
		  <div class="col-md-12">




<div class="col-md-12">
      
          
           <div class="content-box-large">
		   
		     <a href="test_dashboard.php">Go Back</a>  
			  <div class="panel-heading">
					<div class="panel-title">
					<h2>Users List</h2>
                    </div>					
			  </div>
  				<div class="panel-body">


				
<?php
//print $_SESSION['teacher_id'];

$rowsPerPage = 10;

// by default we show first page
$pageNum = 1;

// if $_GET['page'] defined, use it as page number
if(isset($_GET['page']))
{
	$pageNum = $_GET['page'];
}

// counting the offset
$offset = ($pageNum - 1) * $rowsPerPage;


$sql = "SELECT * FROM  student_tb ";
$pagingQuery = "ORDER BY surname DESC LIMIT $offset, $rowsPerPage";

$result = mysqli_query($conn, $sql . $pagingQuery) or die(mysqli_error());

print "<table width=\"100%\" class=\"altrowstable\" id=\"alternatecolor\" border='1'>
<tr>

<th><b>SURNAME</b></th>
<th><b>OTHER NAMES</b></th> 
<th><b>EMAIL</b></th>
</tr>
";

while($rec = mysqli_fetch_array($result)){
		
						
					$id = $rec['student_id'];
					$reg_no = $rec['student_id'];	
					$first_name = $rec['surname'];
					$other_name = $rec['other_names'];
					$email = $rec['email'];
						
							
							$full_name = "$first_name $other_name";	
					print "
					<tr>
					
					
					<td>$first_name</td>					
					<td> $other_name </td>
										
					<td> $email_address </td>
					
					<td> <a href=\"../_stud_test/student_test_result.php?admin_view_user_id=$id&full_name=$full_name\" target='_blank'>See result</a> </td>
					
					</tr>											
					";		}

print "</table>";


// how many rows we have in database
$result  = mysqli_query($conn, $sql) or die('Error, query failed');
$numrows = mysqli_num_rows($result);

// how many pages we have when using paging?
$maxPage = ceil($numrows/$rowsPerPage);

$self = $_SERVER['PHP_SELF'];

// creating 'previous' and 'next' link
// plus 'first page' and 'last page' link

// print 'previous' link only if we're not
// on page one
if ($pageNum > 1)
{
	$page = $pageNum - 1;
	$prev = " <a href=\"$self?page=$page&id=$_GET[id]\">[Prev]</a> ";

	$first = " <a href=\"$self?page=1&id=$_GET[id]\">[First Page]</a> ";
}
else
{
	$prev  = ' [Prev] ';       // we're on page one, don't enable 'previous' link
	$first = ' [First Page] '; // nor 'first page' link
}

// print 'next' link only if we're not
// on the last page
if ($pageNum < $maxPage)
{
	$page = $pageNum + 1;
	$next = " <a href=\"$self?page=$page&id=$_GET[id]\">[Next]</a> ";

	$last = " <a href=\"$self?page=$maxPage&id =$_GET[id]\">[Last Page]</a> ";
}
else
{
	$next = ' [Next] ';      // we're on the last page, don't enable 'next' link
	$last = ' [Last Page] '; // nor 'last page' link
}

// print the page navigation link
echo $first . $prev . " Showing page <strong>$pageNum</strong> of <strong>$maxPage</strong> pages " . $next . $last;

if ($maxPage == 0) {
print "<p><B>SORRY</B> No record";
}
?>
                 
				 
				 
				 
				 
				 </div>
  			</div>
		  </div>
		</div>
    </div>
	
<?php include("../footer.php"); ?>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://code.jquery.com/jquery.js"></script>
    <!-- jQuery UI -->
    <script src="https://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="../bootstrap/js/bootstrap.min.js"></script>

    <link rel="stylesheet" href="../vendors/morris/morris.css">


    <script src="../vendors/jquery.knob.js"></script>
    <script src="../vendors/raphael-min.js"></script>
    <script src="../vendors/morris/morris.min.js"></script>

    <script src="../vendors/flot/jquery.flot.js"></script>
    <script src="../vendors/flot/jquery.flot.categories.js"></script>
    <script src="../vendors/flot/jquery.flot.pie.js"></script>
    <script src="../vendors/flot/jquery.flot.time.js"></script>
    <script src="../vendors/flot/jquery.flot.stack.js"></script>
    <script src="../vendors/flot/jquery.flot.resize.js"></script>

    <script src="../js/custom.js"></script>
    <script src="../js/stats.js"></script>
  </body>
</html>