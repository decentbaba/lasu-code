<?php 
session_start();
session_destroy(); 
?>



<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>NEMS E-TEST</title>
<link href="asset/style.css" rel="stylesheet" type="text/css" />
<link href="../images/style.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
.style4 {
	color: #FFFFFF;
	font-weight: bold;
}
.style5 {
	color: #FFFFFF;
	font-weight: bold;
}
.style7 {
	color: #FFFFFF;
	font-size: 16pt;
}
-->
</style>
</head>

<body>
<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td>
      <?php include("../banner_login.php"); ?>
    </td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td bgcolor="#62707F"><div align="center" class="style5 style7">LOGOUT</div></td>
  </tr>
  <tr> 
    <td><p class="style4">&nbsp;</p>
      <p align="center" class="style4">Thanks</p>
      <p align="center">You've Successfully Logout</p>
      <p align="center"><a href="index.php">CLICK HERE</a> TO RETURN TO LOGIN </p></td>
  </tr>
</table>
<p>&nbsp;</p>
<p>. </p>



</body>
</html>