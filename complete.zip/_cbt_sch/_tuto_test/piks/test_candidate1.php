<?php 
session_start();

include("1validate.php");

//create and issue query
include("../../conn.php");

$sel_id = $_GET['id'];
$_SESSION['post_apply_id']=$sel_id;
if ($_GET['type']=="0"){ // Not approved			
					
				header("Location:test_candidate.php");
				
}elseif($_GET['type']=="1"){ //Direct to taken
	header("Location:test_candidate_approve_taken.php");
}elseif($_GET['type']=="2"){ //Direct to not taken
	header("Location:test_candidate_approve_not_taken.php");
}

?>