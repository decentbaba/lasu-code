<?php 
session_start();


include("1validate.php");

//create and issue query
if(isset($_SESSION['sch_db'])){
	include("../../conn_dynamic.php");	
}else{
	include("../../conn.php");	
}



if ($_POST['ready']=="go"){
	
	
//exit('Stop');

include("pin_gen_function.php");
$pin_var = randomizer(5);


		include("upload1.php");

		include("upload2.php");

		include("upload3.php");

		include("upload4.php");

		include("upload5.php");

		include("upload6.php");

		

		$Q = mysqli_escape_string($conn, $_POST['Q']);

		$Q_ = nl2br($Q);

		

		$OPT1 = mysqli_escape_string($conn, $_POST['OPT1']);

		$OPT1_ = nl2br($OPT1);

		

		$OPT2 = mysqli_escape_string($conn, $_POST['OPT2']);

		$OPT2_ = nl2br($OPT2);

		

		$OPT3 = mysqli_escape_string($conn, $_POST['OPT3']);

		$OPT3_ = nl2br($OPT3);

		

		$OPT4 = mysqli_escape_string($conn, $_POST['OPT4']);

		$OPT4_ = nl2br($OPT4);

		

		$test_id = mysqli_escape_string($conn, $_POST['test_id']);
		$answer = mysqli_escape_string($conn, $_POST['answer']);
		$ans = mysqli_escape_string($conn, $_POST['ans']);

		$ans_ = nl2br($ans);

		

					
			if(isset($_REQUEST['edit'])){
				
				
				
				$question_id = mysqli_escape_string($conn, $_REQUEST['edit']);
				
				
				$sql = "UPDATE j_nems_question SET 
				question='$Q_',
				question_img='$fn1',
				optionA_detail='$OPT1_', 
				optionA_img='$fn2',
				optionB_detail='$OPT2_',
				optionB_img='$fn3',
				optionC_detail='$OPT3_',
				optionC_img='$fn4',
				optionD_detail='$OPT4_',
				optionD_img='$fn5',
				correct_option='$answer',
				correct_option_detail='$ans_',
				ans_img='$fn6' 

				WHERE id ='$question_id'";
				
				mysqli_query($conn, $sql) or die(mysqli_error($conn));
				
				header("Location:test_question.php?msg=1&id=$_POST[test_id]");
				
				
			}else{
							

					$sql="INSERT INTO j_nems_question values (

					DEFAULT,'$test_id',

					'$Q_', '$fn1',

					'A','$OPT1_', '$fn2',

					'B', '$OPT2_', '$fn3',

					'C','$OPT3_', '$fn4',

					'D','$OPT4_', '$fn5',

					'$answer',

					'$ans_', '$fn6',
					'$_SESSION[id]'
					)"; 	

							mysqli_query($conn, $sql) or die(mysqli_error($conn));	

							

							$recent_question_id = mysqli_insert_id($conn);

							

							
								header("Location:test_question.php?msg=1&id=$_POST[test_id]");		
			}
		

}

?>
