<?php
//create and issue query
include("banner_conn.php");		

//Its a Teacher
if(isset($_POST['user_name'])){
	$user_name = mysqli_escape_string($conn, $_POST['user_name']);
	$password = mysqli_escape_string($conn, $_POST['password']);
	
	
				
				$sql3 = "SELECT * FROM nems_teacher WHERE PIN = '$password' AND first_name = '$user_name'";
				$result3 = mysqli_query($conn, $sql3) or die(mysqli_error());				
				if (mysqli_num_rows($result3) == 1) {
					$info3 = mysqli_fetch_array($result3);
						$teacher_id = $info3['teacher_id'];
						$first_name = $info3['first_name'];
						$other_name = $info3['other_name'];
						
						session_start();
						$_SESSION['id']=$school_id;
					
						$_SESSION['teacher_id']=$teacher_id;
						$_SESSION['first_name']=$first_name;
						$_SESSION['other_name']=$other_name;
						$_SESSION['password']=$other_name;
						
						/*
						$_SESSION['address']=$address;
						$_SESSION['logo']="<img src=\"../admin/SCH_LOGO/$logo\" width=\"120\">";
						$_SESSION['privilege_id']=$id;	
						$_SESSION['u']=$user_id;	
						$_SESSION['p']=$password;	
						$_SESSION['s_n']="<font color=#993366>".$s_n."</font>";	
						*/
						
						$_SESSION['type']="teacher";
							
							header("Location:_tuto_test/test_dashboard.php");
				}else {
					print "
					<br>
					<br>
					<br>
					<br>
					Sorry: either the User ID or Password, you provide is incorrect. 
					<p>
					<a href=\"../index.php\">Click here to try again</a>
					";
			
			}
}

?>