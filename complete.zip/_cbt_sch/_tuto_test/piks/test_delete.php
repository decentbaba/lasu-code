<?php 
session_start();

include("1validate.php");

include("banner_conn.php");

$id = mysqli_real_escape_string($conn, $_GET['id']);

if (isset($id)){


		$query  = "DELETE FROM j_nems_post WHERE id = '$id' AND com_id='$_SESSION[teacher_id]'";
		$result = mysqli_query($conn, $query) or die(mysqli_error());

	header("Location:test_dashboard.php?del_msg=1");

}
?>