<?php 
include("banner1.php"); 
//Get the company name
include("comp_set.php");

$pst = mysqli_real_escape_string($conn, $_POST['pst']);
$post_id_entered = mysqli_escape_string($conn, $_REQUEST['id']);

if ($_POST['ready']=="update"){

		$sql4 = "SELECT * FROM j_nems_deadline WHERE com_id = '$_SESSION[id]' AND post_id='$post_id_entered'";
		$sql_query = mysqli_query($conn, $sql4) or die(mysqli_error());
		
		
			if (mysqli_num_rows($sql_query) == 0) {
				//Record DOES NOT exist, insert
				$sql2="INSERT INTO j_nems_deadline 
				VALUES (DEFAULT,'$pst','$post_id_entered', '$_SESSION[id]')";
				mysqli_query($conn, $sql2) or die(mysqli_error());
				
				$msg = "Inserted";
			}else{
				//Record exists, the update 				
				$sql = "UPDATE j_nems_deadline SET status = '$pst' WHERE com_id = '$_SESSION[id]' AND post_id='$post_id_entered'";
				mysqli_query($conn, $sql) or die(mysqli_error());
								
				$msg = "Updated!";	
				
			}	

}

$sql_reg = "SELECT * FROM j_nems_deadline WHERE com_id = '$_SESSION[id]' AND post_id='$post_id_entered'";
$sql_reg_query = mysqli_query($conn, $sql_reg) or die(mysqli_error());
$data = mysqli_fetch_array($sql_reg_query);

$status = $data['status'];

?>




    <div class="page-content">
    	<div class="row">
		  
		  <div class="col-md-12">
          
          
           <div class="content-box-large">
			  <div class="panel-heading">
					<div class="panel-title">
					<a href="test_dashboard_detail.php?id=<?php print $_REQUEST['id']; ?>">Go Back</a>					
						<h2>Status</h2>
                    </div>					
			  </div>
  				<div class="panel-body">
				
<?php
if(isset($msg)){
	print $msg;
}
?>
	
<form id="form1" name="form1" method="post" action="test_deadline.php">
 <div class="form-group">
	
    <div class="col-sm-7">
		
		<select name="pst" id="pst" class="form-control">            
			<?php
			if($status=="1"){
				print "<option selected=\"selected\" value=\"1\">ACTIVE</option>
				<option value=\"\">NOT ACTIVE</option>
				";
			}else{
				print "<option selected=\"selected\" value=\"\">NOT ACTIVE</option>
				<option value=\"1\">ACTIVE</option>
				";
			}
			?>          
          </select>
		  
	</div>	
	<label class="col-sm-2 control-label">
		<input name="id" type="hidden" value="<?php print $post_id_entered; ?>" />
		<input name="ready" type="hidden"  value="update" />
		<button type="submit" class="btn btn-primary">Submit</button>
	</label>
</div>

</form>
</div>
</div>
</div>


		</div>
    </div>

       
    <?php include("../footer.php"); ?>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://code.jquery.com/jquery.js"></script>
    <!-- jQuery UI -->
    <script src="https://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="../bootstrap/js/bootstrap.min.js"></script>

    <link rel="stylesheet" href="../vendors/morris/morris.css">


    <script src="../vendors/jquery.knob.js"></script>
    <script src="../vendors/raphael-min.js"></script>
    <script src="../vendors/morris/morris.min.js"></script>

    <script src="../vendors/flot/jquery.flot.js"></script>
    <script src="../vendors/flot/jquery.flot.categories.js"></script>
    <script src="../vendors/flot/jquery.flot.pie.js"></script>
    <script src="../vendors/flot/jquery.flot.time.js"></script>
    <script src="../vendors/flot/jquery.flot.stack.js"></script>
    <script src="../vendors/flot/jquery.flot.resize.js"></script>

    <script src="../js/custom.js"></script>
    <script src="../js/stats.js"></script>
  </body>
</html>