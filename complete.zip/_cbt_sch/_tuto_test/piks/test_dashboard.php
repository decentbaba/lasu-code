<?php include("banner1.php"); ?>
<?php
if($_POST['ready']=="go"){
	if (($_POST['pst']!="")||($_POST['detail']!="")){
	
	
		 
	   $pst = mysqli_escape_string($conn, $_POST['pst']);
	   $type = mysqli_escape_string($conn, $_POST['type']);
	   $detail = mysqli_escape_string($conn, $_POST['detail']);
	   $attempt = mysqli_escape_string($conn, $_POST['attempt']);
	   
	   $teacher = mysqli_escape_string($conn, $_POST['teacher']);
	   
	  
			$sql11="INSERT INTO j_nems_post VALUES (DEFAULT,'$pst',
			'$detail','$_SESSION[id]','$type','$attempt','$teacher')"; 	
			mysqli_query($conn, $sql11) or die(mysqli_error($conn));
			$post_id = mysqli_insert_id($conn);
			
	
// Setup instruction by default	
$instruction = "$detail
<hr>
<br />
1. 50% Correct Answer is the pass mark <br />
2. You have 60 minutes to complete the test <br />
3. Do not click the browser refresh button when taken the test <br />
4. After submitting do not click the browser back button <br />
5. Cheating is not allowed. <br />
<br />
Thank you";		
					$sql="INSERT INTO j_nems_instruction 
					VALUES (DEFAULT,'$instruction','$_SESSION[id]','$post_id')";
					mysqli_query($conn, $sql) or die(mysqli_error());
					
					
// Setup pass percentage
				$sql2="INSERT INTO j_nems_limit 
				VALUES (DEFAULT,'50','$_SESSION[id]','$post_id')";
				mysqli_query($conn, $sql2) or die(mysqli_error());

// Setup pass percentage
				$thirty_min = (30 * 60); //convert 30 min to seconds
				$sql2="INSERT INTO j_nems_timer  
				VALUES (DEFAULT,'$thirty_min','$post_id','$_SESSION[id]')";
				mysqli_query($conn, $sql2) or die(mysqli_error());				

// Setup the status
				$sql2="INSERT INTO j_nems_deadline 
				VALUES (DEFAULT,'1','$post_id', '$_SESSION[id]')";
				mysqli_query($conn, $sql2) or die(mysqli_error());				
				
							
			$msg = "<font color=\"blue\">Done!</font>";
	
	}else{
		$msg = "<font color=\"red\">Please enter value for Title and Description field !</font>";
	}
}

//--------------------------- EDIT TEST ---------------------------

if(isset($_REQUEST['edited_test'])){
	$id = mysqli_escape_string($conn, $_POST['edited_test']);
	$pst = mysqli_escape_string($conn, $_POST['pst']);
	$detail = mysqli_escape_string($conn, $_POST['detail']);
	$type = mysqli_escape_string($conn, $_POST['type']);
	$attempt = mysqli_escape_string($conn, $_POST['attempt']);
	$teacher = mysqli_escape_string($conn, $_POST['teacher']);
	
	$sql = "UPDATE j_nems_post SET post_name='$pst', detail='$detail', 
	test_type = '$type', num_attempt = '$attempt', user_id='$teacher' WHERE id = '$id' AND com_id='$_SESSION[id]'";
	mysqli_query($conn, $sql) or die(mysqli_error());
	
	$msg = "<font color=\"blue\">Edited!</font>";
	
}


if(isset($_REQUEST['edit_test_id'])){
$id = mysqli_escape_string($conn, $_REQUEST['edit_test_id']);
$sql_class2 = "SELECT * FROM j_nems_post WHERE id = '$id' AND com_id='$_SESSION[id]'";
$sql_class_query2 = mysqli_query($conn, $sql_class2) or die(mysqli_error());

	$select_class2 = mysqli_fetch_array($sql_class_query2);
		$c_id = $select_class2['id'];
		$post_name = $select_class2['post_name'];
		$detail = $select_class2['detail'];
		$test_type = $select_class2['test_type'];
		$num_attempt = $select_class2['num_attempt'];
		$user_id = $select_class2['user_id'];
		
		$see_test_title = " value=\"$post_name\" ";
		$see_test_detail = "$detail";
		 
		   
		  
		
}
?>




    <div class="page-content">
    	<div class="row">
		  
		  <div class="col-md-6">
          
          
           <div class="content-box-large">
			  <div class="panel-heading">
					<div class="panel-title">
					<a href="../../_sch/home.php">Go Back</a>
					<?php if(isset($_REQUEST['edit_test_id'])){
						print "<a href='test_dashboard.php'>Back</a><br/><h2>Edit Test</h2>";
					}else{
						print "<h2>Setup Test</h2>";
					}?>
						
                    </div>					
			  </div>
  				<div class="panel-body">
				
	
	<div align="center"><a href="test_student_register.php"><strong>REGISTER STUDENTS</strong></a> | <a href="student_list.php">STUDENT LIST </a></div>
	
	<span style="color: #0099CC">
            <?php 
					if(isset($msg)){
						print $msg; 
					}
					if($_GET['del_msg']=='1'){
						print "<font color=\"blue\">Deleted</font>"; 
					}
					
					?>
          </span>
		  
		  
	
 <form id="form1" name="form1" method="post" action="test_dashboard.php">	
 
 <?php
if(isset($_REQUEST['edit_test_id'])){
	print "<input name='edited_test' type='hidden' id='ready' value=\"$_REQUEST[edit_test_id])\" />";
}else{
	print "<input name='ready' type='hidden' id='ready' value='go' />";
}
 ?>
 
<div class="form-group">
	<label class="col-sm-3 control-label">Title</label>
    <div class="col-sm-7">
		<input name="pst" type="text" id="pst" class="form-control" <?php print $see_test_title; ?> />		
	</div>	
</div>

<div class="form-group">
	<label class="col-sm-3 control-label">Description</label>
    <div class="col-sm-7">		
		<textarea name="detail" id="detail" cols="80" rows="8" class="form-control"><?php print $see_test_detail; ?></textarea>
	</div>	
</div>

<div class="form-group">
	<label class="col-sm-3 control-label">Type</label>
    <div class="col-sm-7">	
		<select name="type" id="type" class="form-control">
		<?php
		if(isset($_REQUEST['edit_test_id'])){
			if($test_type == "open"){
			   print "
			   	<option selected=\"selected\">open</option>
            	<option>close</option>
				<option>applicant</option>
			   ";
			  
        
				$sql_class = "SELECT * FROM nems_class ";
				$sql_class_query = mysqli_query($conn, $sql_class) or die(mysqli_error());
				
					while($select_class = mysqli_fetch_array($sql_class_query)) {
						$c_id = $select_class['class_id'];
						$class_name = $select_class['name'];			 		
						print "<option value=\"$c_id\">".$class_name."</option>";
					}
                    
       
		   }elseif($test_type == "close"){
			   print "
			   	<option>open</option>
				<option>applicant</option>
            	<option selected=\"selected\">close</option>
			   ";
			   
			    $sql_class = "SELECT * FROM nems_class ";
				$sql_class_query = mysqli_query($conn, $sql_class) or die(mysqli_error());
				
					while($select_class = mysqli_fetch_array($sql_class_query)) {
						$c_id = $select_class['class_id'];
						$class_name = $select_class['name'];			 		
						print "<option value=\"$c_id\">".$class_name."</option>";
					}
			
		   }elseif($test_type == "applicant"){
			   print "
			   	<option>open</option>
				<option>close</option>
            	<option selected=\"selected\">applicant</option>
			   ";
			   
			    $sql_class = "SELECT * FROM nems_class ";
				$sql_class_query = mysqli_query($conn, $sql_class) or die(mysqli_error());
				
					while($select_class = mysqli_fetch_array($sql_class_query)) {
						$c_id = $select_class['class_id'];
						$class_name = $select_class['name'];			 		
						print "<option value=\"$c_id\">".$class_name."</option>";
					}
					
		   }else{
			   $sql_class = "SELECT * FROM nems_class ";
				$sql_class_query = mysqli_query($conn, $sql_class) or die(mysqli_error());
				
					while($select_class = mysqli_fetch_array($sql_class_query)) {
						$c_id = $select_class['class_id'];
						$class_name = $select_class['name'];
                        if($test_type == $c_id)	{
							print "<option value=\"$c_id\" selected=\"selected\">".$class_name."</option>";
						}else{						
							print "<option value=\"$c_id\">".$class_name."</option>";
						}
					}
				
				 print "
			   	<option>open</option>
            	<option>close</option>
				<option>applicant</option>
			   ";
		   }
		}else{ //Not in edit mode
			print "
			   	<option>open</option>
            	<option>close</option>
			   ";

					$sql_class = "SELECT * FROM nems_class ";
				    $sql_class_query = mysqli_query($conn, $sql_class) or die(mysqli_error());
				
					while($select_class = mysqli_fetch_array($sql_class_query)) {
						$c_id = $select_class['class_id'];
						$class_name = $select_class['name'];			 		
						print "<option value=\"$c_id\">".$class_name."</option>";
					}
		}
		?>            
        </select>
		<br/>
		<b>GENERAL</b>
		<br/>		
		<strong>Open:</strong> Student/Candidate takes test without any approval from you.
		<br/>
		<strong>Close:</strong> Student/Candidate will require your approval before test can be taken.
		<br/>
		<strong>Applicant:</strong> entrance exam or test
		<br/>
		<b>CLASS SPECIFIC</b>
		<br/>	
		e.g JSS1 only
		
	</div>	
</div>



<div class="form-group">
	<label class="col-sm-3 control-label">How many attempts</label>
    <div class="col-sm-7">	
		<select name="attempt" id="attempt" class="form-control">
		
		<?php 
		if(isset($_REQUEST['edit_test_id'])){
		   if($num_attempt == "Just once"){
			   print "
			   	<option selected=\"selected\">Just once</option>
            	<option>Multiple times</option>
			   ";
		   }else{
			   print "
			   	<option>Just once</option>
            	<option selected=\"selected\">Multiple times</option>
			   ";
		   }
		}else{
			print "
				<option>Just once</option>
				<option selected=\"selected\">Multiple times</option>
			";
		}
		   ?>
		   
            
          </select>
			How many times can a student attempt this test? (e.g Just Once for an Exam)
	</div>	
</div>




<div class="form-group">
	<label class="col-sm-3 control-label">Assign Teacher to add questions</label>
    <div class="col-sm-7">	
		<select name="teacher" class="form-control">
			<option>select</option>
                          <?php
                    $sql_class = "SELECT * FROM nems_teacher WHERE school_id = '$_SESSION[id]' AND category='TEACHING STAFF'";
                    $sql_class_query = mysqli_query($conn, $sql_class) or die(mysqli_error());
                        while($data = mysqli_fetch_array($sql_class_query)) {
                            $teacher_id = $data['teacher_id'];
							$first_name = $data['first_name'];
							$other_name = $data['other_name'];
							$teacher_fullname = "$first_name $other_name";
							
								if((isset($user_id))&&($user_id==$teacher_id)){
									print "<option value=\"$teacher_id\" selected>".$teacher_fullname."</option>";
								}else{							                        
									print "<option value=\"$teacher_id\">".$teacher_fullname."</option>";
								}
									
							}
                            
            						
            ?>
            </select> 
</div>	
</div>


				
<div class="form-group">
	<div class="col-sm-offset-3 col-sm-7">
	<br/><br/>
	<button type="submit" class="btn btn-primary">Submit</button>
    <button type="reset" class="btn btn-primary">Clear</button>
	</div>
</div>   
        
</form>
<br/>
</div>
</div>
</div>





<div class="col-md-6">
          
          
           <div class="content-box-large">
			  <div class="panel-heading">
					<div class="panel-title">
						<h2>Manage Test</h2>
                    </div>					
			  </div>
  				<div class="panel-body">
				


	
<?php
$rowsPerPage = 10;

// by default we show first page
$pageNum = 1;

// if $_GET['page'] defined, use it as page number
if(isset($_GET['page']))
{
	$pageNum = $_GET['page'];
}

// counting the offset
$offset = ($pageNum - 1) * $rowsPerPage;


$sql = "SELECT * FROM j_nems_post WHERE com_id = '$_SESSION[id]'";
$pagingQuery = "ORDER BY id DESC LIMIT $offset, $rowsPerPage";

$result = mysqli_query($conn, $sql . $pagingQuery) or die(mysqli_error());

print "<table class=\"table table-hover\">
<tr>
<th><b>Title</b></th>
<th><b>Number of Questions</b></th>
<th></th>  
</tr>
";

while($rec = mysqli_fetch_array($result)){
		
						
					$id = $rec['id'];	
					$post_name = $rec['post_name'];
					$test_type = $rec['test_type'];
					$num_attempt = $rec['num_attempt'];
					
				
		//Get total num of question set
		$sql1 = "SELECT * FROM j_nems_question WHERE com_id = '$_SESSION[id]' AND test_id='$id'";
		$result1 = mysqli_query($conn, $sql1) or die(mysqli_error());		
		$num_questions = mysqli_num_rows($result1);	
		
		//Get if instructions is set
		$sql2 = "SELECT * FROM j_nems_instruction WHERE com_id = '$_SESSION[id]' AND post_id='$id'";
		$result2 = mysqli_query($conn, $sql2) or die(mysqli_error());
			$info2 = mysqli_fetch_array($result2);
				$instr_status = $info2['instruction'];	
			
		if($instr_status == ""){
			$instr_msg = "Not Available";
		}else{
			$instr_msg = "<b>Available</b>";
		}
		
		//Get the PASS percentage
		$sql3 = "SELECT * FROM j_nems_limit WHERE com_id = '$_SESSION[id]' AND post_id='$id'";
		$result3 = mysqli_query($conn, $sql3) or die(mysqli_error());
		$data2 = mysqli_fetch_array($result3);
		
		$percentage3 = $data2['percenta'];
		if($percentage3 == ""){
			$percent_msg = "N";
		}else{
			$percent_msg = $percentage3."%";
		}
			
			
		//Get the timer 
		$sql4 = "SELECT * FROM j_nems_timer WHERE com_id = '$_SESSION[id]' AND post_id='$id'";
		$result4 = mysqli_query($conn, $sql4) or die(mysqli_error());
		$data4 = mysqli_fetch_array($result4);
		
		$time_set = $data4['time_set'];
		$time_set = ($time_set/60);
		if($time_set == ""){
			$time_set_msg = "Not Available";
		}else{
			$time_set_msg = "<b>".$time_set." Minutes</b>";
		}
		
		//Get the Recruiting status
		$sql5 = "SELECT * FROM j_nems_deadline WHERE com_id = '$_SESSION[id]' AND post_id='$id'";
		$result5 = mysqli_query($conn, $sql5) or die(mysqli_error());
		$data5 = mysqli_fetch_array($result5);
		
		$status = $data5['status'];
		if($status == "1"){
			$status_msg = "<b>Active</b>";
		}else{
			$status_msg = "Not Active";
		}
		
		
		//How many times taken =============================================================
		$sql6 = "SELECT * FROM j_nems_result_list WHERE test_id = '$id'";
		$result6 = mysqli_query($conn, $sql6) or die(mysqli_error());
		$data6= mysqli_num_rows($result6);
		
		
		//Get num of pending test
		$sql8 = "SELECT * FROM nems_test_mgt WHERE 
		tutor_id = '$_SESSION[id]' AND test_id='$id' AND test_status=''";
		$result8 = mysqli_query($conn, $sql8) or die(mysqli_error());
		$pending =  mysqli_num_rows($result8);
		
		$sql9 = "SELECT * FROM nems_test_mgt WHERE 
		tutor_id = '$_SESSION[id]' AND test_id='$id' AND test_status='1'";
		$result9= mysqli_query($conn, $sql9) or die(mysqli_error());
		$all_approved =  mysqli_num_rows($result9);
		
		
		//Type Option selection
		$test_type_upper = strtoupper($test_type);
		if($test_type_upper == "CLOSE"){
			$type_format = "<a href=\"test_candidate1.php?id=$id&type=0 \"><b>$test_type_upper</b> 
			click to approve students <b>[$pending pendings]</b>
			</a>
			&nbsp;&nbsp;&nbsp;|
			<a href=\"test_candidate1.php?id=$id&type=2 \">Total Approved($all_approved)</a>
			 ";
		}else{ // OPEN
			$type_format = "OPEN";
		}



			
					print "
					<tr>
					<td><a href=\"test_dashboard_detail.php?id=$id \"><b>$post_name</b></a></td>
					<td>$num_questions Questions</td>										
					<td><a href=\"test_dashboard_detail.php?id=$id \">Detail</a></td> 
					</tr>
											
					";
									

		}

print "</table>";


// how many rows we have in database
$result  = mysqli_query($conn, $sql) or die('Error, query failed');
$numrows = mysqli_num_rows($result);

// how many pages we have when using paging?
$maxPage = ceil($numrows/$rowsPerPage);

$self = $_SERVER['PHP_SELF'];

// creating 'previous' and 'next' link
// plus 'first page' and 'last page' link

// print 'previous' link only if we're not
// on page one
if ($pageNum > 1)
{
	$page = $pageNum - 1;
	$prev = " <a href=\"$self?page=$page&id=$_GET[id]\">[Prev]</a> ";

	$first = " <a href=\"$self?page=1&id=$_GET[id]\">[First Page]</a> ";
}
else
{
	$prev  = ' [Prev] ';       // we're on page one, don't enable 'previous' link
	$first = ' [First Page] '; // nor 'first page' link
}

// print 'next' link only if we're not
// on the last page
if ($pageNum < $maxPage)
{
	$page = $pageNum + 1;
	$next = " <a href=\"$self?page=$page&id=$_GET[id]\">[Next]</a> ";

	$last = " <a href=\"$self?page=$maxPage&id =$_GET[id]\">[Last Page]</a> ";
}
else
{
	$next = ' [Next] ';      // we're on the last page, don't enable 'next' link
	$last = ' [Last Page] '; // nor 'last page' link
}

// print the page navigation link
echo $first . $prev . " Showing page <strong>$pageNum</strong> of <strong>$maxPage</strong> pages " . $next . $last;

if ($maxPage == 0) {
print "<p><B>SORRY</B> No record";
}
?></td>
  </tr>
  <tr> 
    <td colspan="4">&nbsp;</td>
  </tr>
  <tr> 
    <td colspan="4">&nbsp;</td>
  </tr>
</table>






</div>
  			</div>
		  </div>
		</div>
    </div>

       
    <?php include("../footer.php"); ?>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://code.jquery.com/jquery.js"></script>
    <!-- jQuery UI -->
    <script src="https://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="../bootstrap/js/bootstrap.min.js"></script>

    <link rel="stylesheet" href="../vendors/morris/morris.css">


    <script src="../vendors/jquery.knob.js"></script>
    <script src="../vendors/raphael-min.js"></script>
    <script src="../vendors/morris/morris.min.js"></script>

    <script src="../vendors/flot/jquery.flot.js"></script>
    <script src="../vendors/flot/jquery.flot.categories.js"></script>
    <script src="../vendors/flot/jquery.flot.pie.js"></script>
    <script src="../vendors/flot/jquery.flot.time.js"></script>
    <script src="../vendors/flot/jquery.flot.stack.js"></script>
    <script src="../vendors/flot/jquery.flot.resize.js"></script>

    <script src="../js/custom.js"></script>
    <script src="../js/stats.js"></script>
  </body>
</html>