<?php 
include("banner1.php"); 
//Get the company name
include("comp_set.php");


if ($_POST['ready']=="update"){

		$contt = $_POST['content'];
		//$comm2 = nl2br($contt);
		$comm3 = mysqli_escape_string($conn, $contt);
		$post_id_entered = mysqli_escape_string($conn, $_POST['id']);


				$sql4 = "SELECT * FROM j_nems_instruction WHERE com_id = '$_SESSION[id]' AND post_id='$post_id_entered'";
				$sql_query4 = mysqli_query($conn, $sql4) or die(mysqli_error());
				
				
					if (mysqli_num_rows($sql_query4) == 1) {
						//Record exists, the update
						$sql = "UPDATE j_nems_instruction SET instruction='$comm3' WHERE com_id = '$_SESSION[id]' AND post_id='$post_id_entered'";
						mysqli_query($conn, $sql) or die(mysqli_error());
						
						$msg = "Updated";
					}else{	
						//Record DOES NOT exist, insert
						$sql="INSERT INTO j_nems_instruction 
						VALUES (DEFAULT,'$comm3','$_SESSION[id]','$post_id_entered')";
						mysqli_query($conn, $sql) or die(mysqli_error());
						
						$msg = "Inserted!";
					
					}	

}


$post_id_entered = mysqli_escape_string($conn, $_REQUEST['id']);
$sql = "SELECT * FROM j_nems_instruction WHERE com_id = '$_SESSION[id]' AND post_id='$post_id_entered'";
$result = mysqli_query($conn, $sql) or die(mysqli_error());

//get the number of rows in the result set; should be 1 if a matchs
if (mysqli_num_rows($result) == 1) {
	$info = mysqli_fetch_array($result);
		$g_id = $info['id'];	
		$content = $info['instruction'];

}


?>




    <div class="page-content">
    	<div class="row">
		  
		  <div class="col-md-12">
          
          
           <div class="content-box-large">
			  <div class="panel-heading">
					<div class="panel-title">
					<a href="test_dashboard_detail.php?id=<?php print $_REQUEST['id']; ?>">Go Back</a>
					
						<h2>Test Instruction</h2>
                    </div>					
			  </div>
  				<div class="panel-body">
				
<?php
if(isset($msg)){
	print $msg;
}
?>
	
<form id="form1" name="form1" method="post" action="test_instruction.php">
 <div class="form-group">
	
    <div class="col-sm-7">		
		<textarea name="content" rows="10" id="content" class="form-control"><?php print $content; ?></textarea>
	</div>	
	<label class="col-sm-2 control-label">
		<input name="pg" type="hidden" id="pg" value="<?php print $g_id; ?>" />
        <input name="id" type="hidden" value="<?php print $_REQUEST['id']; ?>" />
		<input name="ready" type="hidden"  value="update" />
		<button type="submit" class="btn btn-primary">Submit</button>
	</label>
</div>

</form>
</div>
</div>
</div>


		</div>
    </div>

       
    <?php include("../footer.php"); ?>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://code.jquery.com/jquery.js"></script>
    <!-- jQuery UI -->
    <script src="https://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="../bootstrap/js/bootstrap.min.js"></script>

    <link rel="stylesheet" href="../vendors/morris/morris.css">


    <script src="../vendors/jquery.knob.js"></script>
    <script src="../vendors/raphael-min.js"></script>
    <script src="../vendors/morris/morris.min.js"></script>

    <script src="../vendors/flot/jquery.flot.js"></script>
    <script src="../vendors/flot/jquery.flot.categories.js"></script>
    <script src="../vendors/flot/jquery.flot.pie.js"></script>
    <script src="../vendors/flot/jquery.flot.time.js"></script>
    <script src="../vendors/flot/jquery.flot.stack.js"></script>
    <script src="../vendors/flot/jquery.flot.resize.js"></script>

    <script src="../js/custom.js"></script>
    <script src="../js/stats.js"></script>
  </body>
</html>