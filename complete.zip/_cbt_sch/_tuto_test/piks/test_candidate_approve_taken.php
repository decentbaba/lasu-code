<?php 
include("banner1.php"); 
//Get the company name
include("comp_set.php");

if($_GET['type']=='1'){
	$sel_id = mysqli_real_escape_string($conn, $_GET['id']);
	
	
	$query="
			UPDATE nems_test_mgt SET test_status='' WHERE student_id ='$sel_id' 
			AND test_id = '$_SESSION[post_apply_id]' AND tutor_id = '$_SESSION[teacher_id]' AND taken_test_batch_no = ''"; 
			
	$result = mysqli_query($conn, $query) or die("Invalid character enter...");
		
	$msg="Unapproval was successful";			
}
?>




    <div class="page-content">
    	<div class="row">
		  
		  <div class="col-md-12">
          
          
           <div class="content-box-large">
			  <div class="panel-heading">
					<div class="panel-title">
					<a href="test_dashboard_detail.php?id=<?php print $_SESSION['post_apply_id']; ?>">Go Back</a>					
						<h2>Candidates that have taken the Test</h2>
                    </div>					
			  </div>
  				<div class="panel-body">
				
<?php
			
			print "
			$_SESSION[teacher_id]
			";
				
		//This if for INTERNAL tutor/student
		$sql_reg = "SELECT * FROM nems_test_mgt WHERE 
						tutor_id = '$_SESSION[id]' AND 
						test_id='$_SESSION[post_apply_id]' AND test_status='2'";
		
		$sql_reg_query = mysqli_query($conn, $sql_reg) or die(mysqli_error());
		
		print "
		<table class=\"table table-hover\">
		<tr>	
			<th>No.</th>
			<th>RESULT</th>	
			<th>Surname</th> 
			<th>Othernames</th>
			<th>Gender</th> 	
			<th>Email</th> 
			<th>Detail</th>	
			<th>Unapproved</th>				
		</tr>
		";
		
		$counter = 1;
		
			while($data = mysqli_fetch_array($sql_reg_query)) {
				$student_id = $data['student_id'];
				$test_status = $data['test_status'];
				
						//Check is your student HEVE NOT been approved for this test		
						$sql_class = "SELECT * FROM nems_student WHERE student_id='$student_id'";
									
						$sql_class_query=mysqli_query($conn, $sql_class) or die(mysqli_error());
						
							
							$reg_data = mysqli_fetch_array($sql_class_query);
								$id = $reg_data['student_id'];
								$reg_no = $reg_data['reg_no'];
								$surname = $reg_data['first_name'];
								$othername = $reg_data['other_name'];
								$gender = $reg_data['sex'];
								$dob = $reg_data['DOB'];
								$phone = $reg_data['phone_number'];
								$address = $reg_data['contact_address'];
								$email = $reg_data['email_address'];
								
								$class = $reg_data['class_subject'];
								
								include("../_sch/inc_class.php");
									if(isset($class_name)){
										$class_name_ = "Class: $class_name";	
									}
									
								if($test_status=="2"){ //Taken test
									print "
									<tr>		
										<td>$counter</td>
										<td> 
										<a href=\"result_list.php?reg_no=$id&test_id=$_SESSION[post_apply_id]\">Test Scores</a> 
										</td>
										<td>$surname</td> 
										<td>$othername</td>
										<td>$gender</td> 			
										<td>$email</td> 
										<td>$class_name_ </td> 	
										<td><font color=\"blue\">Has taken the test</font></td> 	
									</tr>		
									";
									
									$counter++;
								}else{
						
									print "
									<tr>		
										<td>$counter</td>
										<td> 
										<font color=\"#FF0000\">Not Taken Test</font> 
										</td>
										<td>$surname</td> 
										<td>$othername</td>
										<td>$gender</td> 			
										<td>$email</td> 
										<td>$class_name_ </td> 	
										<td><a href=\"test_candidate.php?id=$id&type=1\">de-approve</a> </td> 	
									</tr>		
									";
									$counter++;
								}
						
								
							
			}
			
		print "</table>";	
			
?>
</div>
</div>
</div>


		</div>
    </div>

       
    <?php include("../footer.php"); ?>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://code.jquery.com/jquery.js"></script>
    <!-- jQuery UI -->
    <script src="https://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="../bootstrap/js/bootstrap.min.js"></script>

    <link rel="stylesheet" href="../vendors/morris/morris.css">


    <script src="../vendors/jquery.knob.js"></script>
    <script src="../vendors/raphael-min.js"></script>
    <script src="../vendors/morris/morris.min.js"></script>

    <script src="../vendors/flot/jquery.flot.js"></script>
    <script src="../vendors/flot/jquery.flot.categories.js"></script>
    <script src="../vendors/flot/jquery.flot.pie.js"></script>
    <script src="../vendors/flot/jquery.flot.time.js"></script>
    <script src="../vendors/flot/jquery.flot.stack.js"></script>
    <script src="../vendors/flot/jquery.flot.resize.js"></script>

    <script src="../js/custom.js"></script>
    <script src="../js/stats.js"></script>
  </body>
</html>