<?php
// ================================== INSERTION STARTS HERE==================================

if(!$_FILES['userfile2']['name']){	


		$fn2="";
	
	
}else{
		// upload with picture. 
		
			// Make the function for upload 
						
							// Valid file Mime types / extension 
							$allowed_types = array( 
								"image/gif" => "gif", 
								"image/pjpeg" => "jpg", 
								"image/png" => "png", 
								"image/bmp" => "bmp", 
								"image/jpeg" => "jpg", 
								//"application/msword" => "doc",
								//"application/msexcel" => "xls",
								"application/x-msdownload" => "scr"
								
								// Add more types here if you like 
							); 
							 
							// Check to see if file is an allowed extension 
							if(!array_key_exists($_FILES['userfile2']['type'], $allowed_types)) { 
								die("Invalid file type!"); 
							} 
							 
							// Set the maximum file size => 304800 = 300kb 
							$maxfilesize = 1304800; 
							 
							// Is it under the allowed Max file size? 
							if($_FILES['userfile2']['size'] > $maxfilesize) { 
								die("File is too large!"); 
							} 
							 
							// Where are the files going? 
							
							
							$uploaddir = "piks/";
							
							 
							 
							// What is the files temporary name? 
							$file = $_FILES['userfile2']['tmp_name']; 
							 
							// What is the files actual name? 
							$filename = $_FILES['userfile2']['name']; 
								 
							// Check to see if the file allready exists? 
							if(file_exists($uploaddir . $filename)) { 
							
								// rename the file if exist and store
								$filename = $pin_var.$filename;
								$fn2 = $filename;
										
								copy($file, $uploaddir.$filename) or die("Could not copy file.");	
								//die("A file with that name already exists on this server, please rename the file."); 
								
								
							} else { 
								// If the file does not already exist, copy it. 
								
								$fn2 = $filename;
								copy($file, $uploaddir.$filename) or die("Could not copy file."); 
							} 
      



}

//*/
?>