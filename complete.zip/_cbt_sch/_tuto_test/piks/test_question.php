<?php include("banner1.php"); ?>
<?php
include("comp_set.php");

if(isset($_REQUEST['edit'])){
	
	
	$test_id = mysqli_escape_string($conn, $_REQUEST['edit']);
	
	$sql1 = "SELECT * FROM j_nems_question WHERE com_id = '$_SESSION[id]' AND id='$test_id'";
	$result1 = mysqli_query($conn, $sql1) or die(mysqli_error());
	
	$info1 = mysqli_fetch_array($result1);
	$counter = $counter + 1;
		 $id=$info1['id'];	
		 $question=$info1['question'];
		 $question_img=$info1['question_img'];
		 
		 $optionA=$info1['optionA'];
		 $optionA_detail=$info1['optionA_detail'];
		 $optionA_img=$info1['optionA_img'];
		 
		 $optionB=$info1['optionB'];
		 $optionB_detail=$info1['optionB_detail'];
		 $optionB_img=$info1['optionB_img'];
		 
		 $optionC=$info1['optionC'];
		 $optionC_detail=$info1['optionC_detail'];
		 $optionC_img=$info1['optionC_img'];
		 
		 $optionD=$info1['optionD'];
		 $optionD_detail=$info1['optionD_detail'];
		 $optionD_img=$info1['optionD_img'];
		 
		 $correct_option=$info1['correct_option'];
		 $correct_option_detail=$info['correct_option_detail'];
		 $ans_img=$info1['ans_img'];		 
	
}
?>




    <div class="page-content">
    	<div class="row">
		  
		  <div class="col-md-6">
          
          
           <div class="content-box-large">
			  <div class="panel-heading">
					<div class="panel-title">
					<a href="test_dashboard_detail.php?id=<?php print $_REQUEST['id']; ?>">Go Back</a>
					
						<h2><?php //print $_GET['test_name'] ?> <?php print $post_name ?> Questions</h2>
                    </div>					
			  </div>
  				<div class="panel-body">
				
	
	<span style="color: #0099CC">
            <?php
if($_GET['msg']=='1'){
	print "<font color=\"blue\">Done</font>";
}elseif($_GET['msg']=='2'){
	print "<font color=\"blue\">Deleted</font>";
}
?>
          </span>
		  
		  
	

<form action="test_question_setup.php" method="post" enctype="multipart/form-data" name="form1" id="form1">
 
<input name='ready' type='hidden' id='ready' value='go' />
 
<div class="form-group">
	<label class="col-sm-3 control-label">Question</label>
    <div class="col-sm-7">		
		<textarea name="Q" rows="10" id="Q" class="form-control"><?php if(isset($question)){ print $question; } ?></textarea>
		<?php if($question_img != ""){ print "<img src=\"piks/$question_img\" width=\"50%\">"; } ?>
		<input name="userfile1" type="file" id="userfile1" class="form-control" <?php if($question_img != ""){ print "value=\"$question_img\""; }?> />(optional)
	</div>
</div>

<div class="form-group">
	<label class="col-sm-3 control-label">Option A</label>
    <div class="col-sm-7">		
		<textarea name="OPT1" rows="5" id="OPT1" class="form-control"><?php if(isset($optionA_detail)){ print $optionA_detail; } ?></textarea>
		<?php if($optionA_img != ""){ print "<img src=\"piks/$optionA_img\" width=\"50%\">"; } ?>
		<input name="userfile2" type="file" id="userfile2" class="form-control" <?php if($optionA_img != ""){ print "value=\"$optionA_img\""; }?> />(optional)
	</div>	
</div>

<div class="form-group">
	<label class="col-sm-3 control-label">Option B</label>
    <div class="col-sm-7">		
		<textarea name="OPT2" rows="5" id="OPT2" class="form-control"><?php if(isset($optionB_detail)){ print $optionB_detail; } ?></textarea>
		<?php if($optionB_img != ""){ print "<img src=\"piks/$optionB_img\" width=\"50%\">"; } ?>
		<input name="userfile3" type="file" id="userfile3" class="form-control" <?php if($optionB_img != ""){ print "value=\"$optionB_img\""; }?> />(optional)
	</div>	
</div>

<div class="form-group">
	<label class="col-sm-3 control-label">Option C</label>
    <div class="col-sm-7">		
		<textarea name="OPT3" rows="5" id="OPT3" class="form-control"><?php if(isset($optionC_detail)){ print $optionC_detail; } ?></textarea>
		<?php if($optionC_img != ""){ print "<img src=\"piks/$optionC_img\" width=\"50%\">"; } ?>
		<input name="userfile4" type="file" id="userfile4" class="form-control" <?php if($optionC_img != ""){ print "value=\"$optionC_img\""; }?> />(optional)
	</div>	
</div>

<div class="form-group">
	<label class="col-sm-3 control-label">Option D</label>
    <div class="col-sm-7">		
		<textarea name="OPT4" rows="5" id="OPT4" class="form-control"><?php if(isset($optionD_detail)){ print $optionD_detail; } ?></textarea>
		<?php if($optionD_img != ""){ print "<img src=\"piks/$optionD_img\" width=\"50%\">"; } ?>
		<input name="userfile5" type="file" id="userfile5" class="form-control" <?php if($optionD_img != ""){ print "value=\"$optionD_img\""; }?> />(optional)
	</div>	
</div>

<div class="form-group">
	<label class="col-sm-3 control-label">Correct Answer is:</label>
    <div class="col-sm-7">	
		<select name="answer" id="answer" class="form-control">
			<?php 
			if($correct_option=="A"){ 
				print "
				<option selected='selected'>A</option>
                <option>B</option>
                <option>C</option>
                <option>D</option>
				";
			}elseif($correct_option=="B") {
				print "
				<option>A</option>
                <option selected='selected'>B</option>
                <option>C</option>
                <option>D</option>
				";
			}elseif($correct_option=="C") {
				print "
				<option>A</option>
                <option>B</option>
                <option selected='selected'>C</option>
                <option>D</option>
				";
			}elseif($correct_option=="D") {
				print "
				<option'>A</option>
                <option>B</option>
                <option>C</option>
                <option selected='selected'>D</option>
				";
			}else{
				print '
				<option>A</option>
                <option>B</option>
                <option>C</option>
                <option>D</option>
				';
			}
			?>
		
							   
        </select>		
	</div>	
</div>

<div class="form-group">
	<label class="col-sm-3 control-label">Explain Answer (Optional)</label>
    <div class="col-sm-7">		
		<textarea name="ans" rows="5" id="ans" class="form-control"><?php if(isset($correct_option_detail)){ print $correct_option_detail; } ?></textarea>
		<input name="userfile6" type="file" id="userfile6" class="form-control" <?php if($ans_img != ""){ print "value=\"$ans_img\""; }?> />(optional)
	</div>	
</div>


<input name="test_id" type="hidden" id="test_id" value="<?php print $post_id; ?>" />				
<div class="form-group">
	<div class="col-sm-offset-3 col-sm-7">
	
	<?php
	if(isset($_REQUEST['edit'])){
		
		print '<button type="submit" class="btn btn-primary">Update</button>';
		print "<input name='edit' type='hidden' value=\"$_REQUEST[edit])\" />";
	}else{
		print '<button type="submit" class="btn btn-primary">Submit</button>';
	}
	?>
	
    
	</div>
</div>   
        
</form>
<br/>
</div>
</div>
</div>





<div class="col-md-6">
          
          
           <div class="content-box-large">
			  <div class="panel-heading">
					<div class="panel-title">
						<h2>
						<?php
						print "<b>$post_name</b>";
						?>
						</h2>
                    </div>					
			  </div>
  				<div class="panel-body">
				


	
<?php
print "<table class=\"table table-hover\">";

$sql = "SELECT * FROM j_nems_question WHERE com_id = '$_SESSION[id]' AND test_id='$post_id'";
$result = mysqli_query($conn, $sql) or die(mysqli_error());
print "<table width=100% border=0>";
$counter = 0;


while($info = mysqli_fetch_array($result)){
	$counter = $counter + 1;
		 $id=$info['id'];	
		 $question=$info['question'];
		 $question_img=$info['question_img'];
		 $optionA=$info['optionA'];
		 $optionA_detail=$info['optionA_detail'];
		 $optionA_img=$info['optionA_img'];
		 $optionB=$info['optionB'];
		 $optionB_detail=$info['optionB_detail'];
		 $optionB_img=$info['optionB_img'];
		 $optionC=$info['optionC'];
		 $optionC_detail=$info['optionC_detail'];
		 $optionC_img=$info['optionC_img'];
		 $optionD=$info['optionD'];
		 $optionD_detail=$info['optionD_detail'];
		 $optionD_img=$info['optionD_img'];
		 $correct_option=$info['correct_option'];
		 $correct_option_detail=$info['correct_option_detail'];
		 $ans_img=$info['ans_img'];		 

if($question_img != ""){
	$im1="<img src=\"piks/$question_img\" width=\"100%\">";
}
if($optionA_img != ""){
	$im2="<img src=\"piks/$optionA_img\" width=\"100%\">";
}
if($optionB_img != ""){
	$im3="<img src=\"piks/$optionB_img\" width=\"100%\">";
}
if($optionC_img != ""){
	$im4="<img src=\"piks/$optionC_img\" width=\"100%\">";
}
if($optionD_img != ""){
	$im5="<img src=\"piks/$optionD_img\" width=\"100%\">";

}

if($ans_img != ""){
	$im6="<img src=\"piks/$ans_img\" width=\"100%\">";
}
	print "	<tr>
	<td><b> $counter. $question </b>
	<br />
	$im1
	<br /><br />
	A. $optionA_detail
	<br />
	$im2
	<br /><br />
	B. $optionB_detail
	<br />
	$im3
	<br /><br />
	C. $optionC_detail
	<br />
	$im4
	<br /><br />
	D. $optionD_detail
	<br />
	$im5
	<br /><br />
	<b><font color=\"green\">ANSWER: $correct_option</a></b>
	<br />
	$correct_option_detail<br />
	$im6
	<br />
	<a href=\"test_question_delete.php?del_id=$id&id=$post_id\">Delete</a> | <a href=\"test_question.php?edit=$id&id=$post_id\">Edit</a>
	<hr>
	</td>
	</tr>
	<tr>
	<td></td>
	</tr>		
	";
	$_SESSION['num_of_question']=$counter;
}
print "</table>";
?>




</div>
  			</div>
		  </div>
		</div>
    </div>

       
    <?php include("../footer.php"); ?>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://code.jquery.com/jquery.js"></script>
    <!-- jQuery UI -->
    <script src="https://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="../bootstrap/js/bootstrap.min.js"></script>

    <link rel="stylesheet" href="../vendors/morris/morris.css">


    <script src="../vendors/jquery.knob.js"></script>
    <script src="../vendors/raphael-min.js"></script>
    <script src="../vendors/morris/morris.min.js"></script>

    <script src="../vendors/flot/jquery.flot.js"></script>
    <script src="../vendors/flot/jquery.flot.categories.js"></script>
    <script src="../vendors/flot/jquery.flot.pie.js"></script>
    <script src="../vendors/flot/jquery.flot.time.js"></script>
    <script src="../vendors/flot/jquery.flot.stack.js"></script>
    <script src="../vendors/flot/jquery.flot.resize.js"></script>

    <script src="../js/custom.js"></script>
    <script src="../js/stats.js"></script>
  </body>
</html>