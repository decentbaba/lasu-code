<?php
if (!$_SESSION['p']){
	print "
	
	<p>
	Sorry your session has ended</font></b></p>
         <a href=\"../index.php\">Click here</a> and  Login again.";
	exit;
}
?>