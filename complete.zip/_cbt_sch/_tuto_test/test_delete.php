<?php 
session_start();

if (!$_SESSION['p']){
	print "
	
	<p>
	Sorry your session has ended</font></b></p>
         <a href=\"../index.php\">Click here</a> and  Login again.";
	exit;
}



if(isset($_SESSION['sch_db'])){
	include("../../conn_dynamic.php");	
}else{
	include("../../conn.php");	
}



$delete_id = mysqli_real_escape_string($conn, $_GET['id']);

//$delete_id = mysqli_escape_string($conn, $_REQUEST['id']);

//$delete_id = $_GET['id'];



if(isset($delete_id)){
 

		$query  = "DELETE FROM j_nems_post WHERE id = '$delete_id'";
		$result = mysqli_query($conn, $query) or die(mysqli_error());

	header("Location:test_dashboard.php?del_msg=1");

}
?>