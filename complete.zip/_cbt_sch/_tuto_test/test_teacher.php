<?php
//create and issue query
include("banner_conn.php");		

//Its a Teacher
if(isset($_POST['user_name'])){
	$user_name = mysqli_escape_string($conn, $_POST['user_name']);
	$password = mysqli_escape_string($conn, $_POST['password']);
	
	
				
				$sql3 = "SELECT * FROM accounts WHERE password = '$password' AND username = '$user_name'";
				$result3 = mysqli_query($conn, $sql3) or die(mysqli_error());				
				if (mysqli_num_rows($result3) == 1) {
					$info3 = mysqli_fetch_array($result3);
						$teacher_id = $info3['id'];
						$first_name = $info3['first_name'];
						$other_name = $info3['other_name'];
						
						session_start();
											
						$_SESSION['teacher_id']=$teacher_id;
						$_SESSION['first_name']=$first_name;
						$_SESSION['other_name']=$other_name;
						$_SESSION['password']=$other_name;
						
						
						
						$_SESSION['type']="teacher";
							
							header("Location:_tuto_test/test_dashboard.php");
				}else {
					print "
					<br>
					<br>
					<br>
					<br>
					Sorry: either the User ID or Password, you provide is incorrect. 
					<p>
					<a href=\"../index.php\">Click here to try again</a>
					";
			
			}
}

?>