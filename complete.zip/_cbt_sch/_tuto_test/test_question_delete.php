<?php 
session_start();
?>

<?php
include("1validate.php");

//create and issue query
include("../conn.php");

$del_id = mysqli_escape_string($conn, $_GET['del_id']);
$id = mysqli_escape_string($conn, $_GET['id']);

$query  = "DELETE FROM j_nems_question WHERE id = '$del_id' AND com_id='$_SESSION[id]'";
$result = mysqli_query($conn, $query) or die("Invalid character enter...");
header("Location:test_question.php?msg=2&id=$id");

?>