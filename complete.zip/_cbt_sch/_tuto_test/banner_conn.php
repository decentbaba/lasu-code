<?php 
if(isset($_SESSION['sch_db'])){
	include("../conn_dynamic.php");	
}else{
	include("../conn.php");	
}
?>