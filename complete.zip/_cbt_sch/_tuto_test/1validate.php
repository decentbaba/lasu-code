<?php
if (!$_SESSION['teacher_id']){
	print "
	
	<p>
	Sorry your session has ended</font></b></p>
         <a href=\"../index.php\">Click here</a> and  Login again.";
	exit;
}
?>