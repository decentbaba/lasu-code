<?php 
include("banner1.php");
$student_id = mysqli_real_escape_string($conn, $_GET['student_id']);

$sql_class = "SELECT * FROM student_tb WHERE student_id='$student_id'";
$sql_class_query=mysqli_query($conn, $sql_class) or die(mysqli_error());
$reg_data = mysqli_fetch_array($sql_class_query);
$surname = $reg_data['surname'];
$othername = $reg_data['other_names'];
								

$sql = "SELECT * FROM j_nems_post WHERE com_id = '$_SESSION[id]' AND id='$_SESSION[post_apply_id]'";
$result = mysqli_query($conn, $sql) or die(mysqli_error());
$rec = mysqli_fetch_array($result);
$id = $rec['id'];	
$post_name = $rec['post_name'];



?>


<div class="page-content">
    	<div class="row">
		  
		  <div class="col-md-12">
          
          
           <div class="content-box-large">
				<a href="test_candidate_approve_taken.php">Go Back</a>
				<br/>
		
  				<div class="panel-body">
				Student name: <b><?php print "$surname $othername"; ?></b>
				<br/>
				Subject: <b><?php print $post_name; ?></b>
				<br/>
				
				<hr/>
				<h2>Test Result Retail</h2>
				


<?php
$bat = mysqli_escape_string($conn, $_GET['batch']);
$student_id = mysqli_escape_string($conn, $_GET['student_id']);

$sql = "SELECT * FROM j_nems_result WHERE user_email='$student_id' AND batch_num_val='$bat'";
$result = mysqli_query($conn, $sql) or die(mysqli_error());


while($info = mysqli_fetch_array($result)){
$counter = $counter + 1;
		 $id=$info['id'];
		 $user_email=$info['user_email'];
		 $question_id=$info['question_id'];
		 $user_answer=$info['user_answer'];
		 $test_summary=$info['test_summary'];
		 
		    $sql_in = "SELECT * FROM  j_nems_question WHERE id='$question_id'";
			$result_in = mysqli_query($conn, $sql_in) or die(mysqli_error());
			
			$info2 = mysqli_fetch_array($result_in);
			
			$id=$info2['id'];
			$question=$info2['question'];
			$question_img=$info2['question_img'];
			
			$optionA=$info2['optionA'];
			$optionA_detail=$info2['optionA_detail'];
			$optionA_img=$info2['optionA_img'];
			
			$optionB=$info2['optionB'];
			$optionB_detail=$info2['optionB_detail'];
			$optionB_img=$info2['optionB_img'];
			
			$optionC=$info2['optionC'];
			$optionC_detail=$info2['optionC_detail'];
			$optionC_img=$info2['optionC_img'];
			
			$optionD=$info2['optionD'];
			$optionD_detail=$info2['optionD_detail'];
			$optionD_img=$info2['optionD_img'];
			
			$correct_option=$info2['correct_option'];
			$correct_option_detail=$info2['correct_option_detail'];
			$ans_img=$info2['ans_img'];
			
			if($question_img==""){
				$ans2_img =""; 
			}else{
				$ans2_img = "<img src=\"recruiter/admin/piks/$question_img\" width=\"400\" />";
			}
	

	if($correct_option == $user_answer){

					print"
					<b>QUESTION NUMBER $counter </b> <br />	
					<b><font color=\"green\" size=\"4\">CORRECT</font></b> <br />
														

					$question <br />
                    $ans2_img	<br />
					<b>Answer:</b> $user_answer 
					<br />
					<hr>
					<br />

					";				


					

		}else{

					print "					
					<b>QUESTION NUMBER $counter</b> <br />	
					<b><font color=\"red\" size=\"4\">WRONG</font></b> <br />	

					$question <br />
                    $ans2_img	<br />

					<b>chose:</b> <font color=\"red\">   $user_answer</font>		
					<br />
					<b>Answer:</b> $correct_option 
					<br />	
					<hr>
					<br />			

					";

		}

}


print  $test_summary;
?>
   
				
</div>
</div>
</div>
</div>
</div>




  <?php include("../footer.php"); ?>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://code.jquery.com/jquery.js"></script>
    <!-- jQuery UI -->
    <script src="https://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="../bootstrap/js/bootstrap.min.js"></script>

    <link rel="stylesheet" href="../vendors/morris/morris.css">


    <script src="../vendors/jquery.knob.js"></script>
    <script src="../vendors/raphael-min.js"></script>
    <script src="../vendors/morris/morris.min.js"></script>

    <script src="../vendors/flot/jquery.flot.js"></script>
    <script src="../vendors/flot/jquery.flot.categories.js"></script>
    <script src="../vendors/flot/jquery.flot.pie.js"></script>
    <script src="../vendors/flot/jquery.flot.time.js"></script>
    <script src="../vendors/flot/jquery.flot.stack.js"></script>
    <script src="../vendors/flot/jquery.flot.resize.js"></script>

    <script src="../js/custom.js"></script>
    <script src="../js/stats.js"></script>
  </body>
</html>