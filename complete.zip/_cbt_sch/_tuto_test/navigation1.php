<div class="sidebar content-box" style="display: block;">
                <ul class="nav">
                    <!-- Main menu -->
                    
<?php
if(is_numeric($_SESSION['u'])){
	
		//Get records, if priviledges is already set

		$query2  = "SELECT * FROM nems_privilege WHERE school_id='$_SESSION[id]' AND user_id='$_SESSION[teacher_id]'";
		$sql_class_query = mysqli_query($conn, $query2) or die(mysqli_error());
		
		if (mysqli_num_rows($sql_class_query) <> 0) {
			
		$data = mysqli_fetch_array($sql_class_query);
				$id = $data['id'];
				
				$user_id = $data['user_id'];
				$password = $data['password'];
				$prev_1 = $data['pr1'];
				$prev_2 = $data['pr2'];
				$prev_3 = $data['pr3'];
				$prev_4 = $data['pr4'];
				$prev_5 = $data['pr5'];
				$prev_6 = $data['pr6'];
				$prev_7 = $data['pr7'];
				$prev_8 = $data['pr8'];
				$prev_9 = $data['pr9'];
				$prev_10 = $data['pr10'];
				$prev_11 = $data['pr11'];
				$prev_12 = $data['pr12'];
				$prev_13 = $data['pr13'];
				$prev_15 = $data['pr15'];
				
				print '<li><a href="home.php"><i class="glyphicon glyphicon-home"></i> Dashboard</a></li>';
				
				if($prev_1=="1"){
					print "<li><a href=\"subject.php\">Setup Subject</a></li>";
				}
				if($prev_2=="1"){
					print "<li><a href=\"class.php\">Setup class</a></li>";
				}
				if($prev_3=="1"){
					print "<li><a href=\"class_subj.php\">Assign subjects to classes</a></li>";
				}
				if($prev_4=="1"){
					print "<li><a href=\"2teaching_staff.php\">Teaching Staff</a></li>";
				}
				if($prev_5=="1"){
					print "<li><a href=\"3non_teaching.php\">Non-Teaching Staff</a></li>";
				}
				if($prev_6=="1"){
					print "<li><a href=\"student.php\">Setup Student</a></li>";
				}
				if($prev_7=="1"){
					print "<li><a href=\"student_manage.php\">Students Record and Fees</a></li>";
				}
				if($prev_8=="1"){
					print "<li><a href=\"store_student_result.php\">Save Test/Exam Scores</a></li>";
				}
				if($prev_9=="1"){
					print "<li><a href=\"student_record_verify_step1.php\">Verify Student Result</a></li>";
				}
				if($prev_10=="1"){
					print "<li><a href=\"student_promote_demote.php\">Promote/Demote Student</a></li>";
				}
				if($prev_11=="1"){
					print "<li><a href=\"payment.php\">Setup School Fees</a></li>";
				}
				
				if($prev_12=="1"){
					print "<li><a href=\"student_manage.php\">Save/View Student Fees</a></li>";
					print "<li><a href=\"filter.php\">Filter Student Debt</a></li>";
					
				}
				
				if($prev_13=="1"){
					print "<li><a href=\"expenses.php\">Income/Expenses</a></li>";
				}

				if($prev_15 != ""){
					print "<li><a href=\"attendance.php\">Attendance</a></li>";
				}
				
				print '
				<li><a href="message_teacher.php">Message</a></li>
				<li><a href="../index.php"><i class="glyphicon glyphicon-eject"></i>Logout</a></li>';
		}
	
}else{
	print '
	 <li><a href="home.php"><i class="glyphicon glyphicon-home"></i> Dashboard</a></li>
                    
					
					
					<li class="submenu">
						<a href="sub_links.php?id=3">
							<i class="glyphicon glyphicon-tasks"></i> Class/Subject
							<span class="caret pull-right"></span>
						</a>
						<!-- Sub menu -->
                         <ul>
                            <li><a href="subject.php">Setup Subjects</a></li>
                            <li><a href="class.php">Setup Classes</a></li>
							<li><a href="class_subj.php">Assign subjects to classes</a></li>
                        </ul>
					</li>
					
					
					
				    <li class="submenu">
						<a href="sub_links.php?id=1">
							<i class="glyphicon glyphicon-stats"></i> Finance
							<span class="caret pull-right"></span>
						</a>
						<!-- Sub menu -->
                         <ul>
                            <li><a href="payment.php">Setup Fees</a></li>
                            <li><a href="expenses.php">Income/Expenses</a></li>
							<li><a href="filter.php">Filter Student Debt</a></li>
                        </ul>
					</li>
					
					<li class="submenu">
						<a href="sub_links.php?id=2">
							<i class="glyphicon glyphicon-pencil"></i> Student
							<span class="caret pull-right"></span>
						</a>
						<!-- Sub menu -->
                         <ul>
                            <li><a href="student.php">Setup Student</a></li>
                            <li><a href="student_manage.php">Students Record and Fees</a></li>
							<li><a href="attendance.php">Attendance</a></li>
							<li><a href="store_student_result.php">Save Tests/Exam Scores</a></li>
                            <li><a href="student_record_verify_step1.php">Verify Student Result</a></li>
							<li><a href="student_promote_demote.php">Promote/Demote Student</a></li>
                        </ul>
					</li>
					
					
					<li class="submenu">
						<a href="sub_links.php?id=4">
							<i class="glyphicon glyphicon-record"></i> Staff
							<span class="caret pull-right"></span>
						</a>
						<!-- Sub menu -->
                         <ul>
                            <li><a href="2teaching_staff.php">Teaching Staff</a></li>
                            <li><a href="3non_teaching.php">Non-Teaching Staff</a></li>
							<li><a href="staff_priviledge.php">Assign Privileges</a></li>
                        </ul>
					</li>       
					
					<li class="submenu">
                         <a href="sub_links.php?id=5">
                            <i class="glyphicon glyphicon-list"></i> School
                            <span class="caret pull-right"></span>
                         </a>
                         <!-- Sub menu -->
                         <ul>
                            <li><a href="edit_school.php">Manage School Detail</a></li>
							<li><a href="../cbt/">Computer Based Test</a></li>
                            <li><a href="message.php">Message Student/Parent</a></li>
                        </ul>
                    </li>
	
	
					  <li><a href="../index.php"><i class="glyphicon glyphicon-eject"></i>Logout</a></li>
	';
	
}
?>

                   
                </ul>
             </div>