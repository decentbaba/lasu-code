<?php 

/*$the_email = "ben@yahoo.com";

if(!filter_var($the_email, FILTER_VALIDATE_EMAIL)){
	print "Invalid email";
}else{
	print "GOOD email";
}
*/
if($_POST['ready']=="go"){
	$value = $_POST['val'];
	
	if(!is_numeric($value)){
		print "Please enter a valid number";
	}else{
		$to_naira = ($value * 170);
		$the_ten_percent_vat = (10/100)*($to_naira/1);
		$ans1 = $to_naira + $the_ten_percent_vat;
		
		$the_twenty_percent = ($ans1 + ($ans1/4));
		$ans2 = $the_twenty_percent;
	}
	//print (10/100)*(20/1);

}
?>

<form id="form1" name="form1" method="post" action="">
  <p>Enter the Value: 
    <input name="val" type="text" id="val" />
  </p>
  <p>Amount enter $
<?php
  if(isset($value)){
  	print $value;
  }
  ?>  
   </p>
  <p>(Value x 170) + (10% VAT) = 
    <b>
  <?php
  if(isset($ans1)){
  	print $ans1;
  }
  ?>
    </b>
  </p>
  <p>25% = 
  <b>
  <?php
  if(isset($ans2)){
  	print $ans2;
  }
  ?>  
  </b>
  </p>
  <p>
    <input type="submit" name="Submit" value="Submit" />
    <input name="ready" type="hidden" id="ready" value="go" />
  </p>
  <p>&nbsp;</p>
</form>
