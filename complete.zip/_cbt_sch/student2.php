<?php include("banner.php"); 

// ================================== INSERTION STARTS HERE==================================


// ====================================================================================================
$pw = mysqli_escape_string($conn, $_POST['pw']);
$fname = mysqli_escape_string($conn, $_POST['fname']);
$other_name = mysqli_escape_string($conn, $_POST['other_name']);
$gender = mysqli_escape_string($conn, $_POST['gender']);
$dob = mysqli_escape_string($conn, $_POST['dob']);
$contact = mysqli_escape_string($conn, $_POST['contact']);
$phone = mysqli_escape_string($conn, $_POST['phone']);
$state = mysqli_escape_string($conn, $_POST['state']);
$country = mysqli_escape_string($conn, $_POST['country']);
$year_session = mysqli_escape_string($conn, $_POST['year_session']);
$class = mysqli_escape_string($conn, $_POST['class']);

$email = mysqli_escape_string($conn, $_POST['email']);



					$add = "INSERT INTO nems_student values 
					('', 'text_only',
					'$pw',
					'0027',					
					'$fname',
					'$other_name',
					'$gender',
					'$dob',
					'',
					'',
					'$email',
					'',
					'',
					'',
					'',					
					'$class',
					now(),'',
					'','','','','','',
					''
					)";
					
					mysqli_query($conn, $add) or die(mysqli_error());						
									
									
					
$msg = "Your registration was successfull";
?>

    <div class="page-content">
    	<div class="row">
		  
		  <div class="col-md-12">
          
          
           <div class="content-box-large">
		   <a href="index.php">Go Back</a>
			  <div class="panel-heading">
					<div class="panel-title">
                    REGISTER TO TAKE A TEST
              </div>					
			  </div>
  				<div class="panel-body">

        		<?php print $msg ?>
                <br/>
                <strong><a href="index.php"><span class="style7">Click here to Login</span></a></strong>

             </div>
             
  			</div>
            
		  </div>
		</div>
    </div>

       
    <?php include("../footer.php"); ?>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://code.jquery.com/jquery.js"></script>
    <!-- jQuery UI -->
    <script src="https://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="../bootstrap/js/bootstrap.min.js"></script>

    <link rel="stylesheet" href="../vendors/morris/morris.css">


    <script src="../vendors/jquery.knob.js"></script>
    <script src="../vendors/raphael-min.js"></script>
    <script src="../vendors/morris/morris.min.js"></script>

    <script src="../vendors/flot/jquery.flot.js"></script>
    <script src="../vendors/flot/jquery.flot.categories.js"></script>
    <script src="../vendors/flot/jquery.flot.pie.js"></script>
    <script src="../vendors/flot/jquery.flot.time.js"></script>
    <script src="../vendors/flot/jquery.flot.stack.js"></script>
    <script src="../vendors/flot/jquery.flot.resize.js"></script>

    <script src="../js/custom.js"></script>
    <script src="../js/stats.js"></script>
  </body>
</html>