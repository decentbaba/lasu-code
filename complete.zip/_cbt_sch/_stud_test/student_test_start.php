<?php 
session_start();
if($_SESSION['user_type']=='applicant'){
	include("applicant_banner1.php");
}else{
	include("banner1.php");
}

if(isset($_GET['pid'])){
	$test_id = mysqli_escape_string($conn, $_GET['pid']);
	$_SESSION['post_id']=$test_id;
	$tut = mysqli_escape_string($conn, $_GET['tut']);
}


if(isset($_GET['pid'])){
	$test_id = mysqli_escape_string($conn, $_GET['pid']);
	$_SESSION['post_id']=$test_id;
}




//===========================================================================
$_SESSION['selected_options'] = "";
$_SESSION['testStartTime'] = new DateTime;
$_SESSION['another_time_start'] = date("h:i A.", time());

//  Retrive the  timer for the test, for a particular post
$sql_reg = "SELECT * FROM j_nems_timer WHERE post_id = '$_SESSION[post_id]'";
$sql_reg_query = mysqli_query($conn, $sql_reg) or die(mysqli_error());
$data = mysqli_fetch_array($sql_reg_query);
$timer = $data['time_set'];
//==========================================================================

$sql2 = "SELECT * FROM j_nems_post WHERE id = '$_SESSION[post_id]'";
		$result2 = mysqli_query($conn, $sql2) or die(mysqli_error());
		$rec = mysqli_fetch_array($result2);		
		$post_name = $rec['post_name'];
		$num_attempt = $rec['num_attempt'];

$sql5 = "SELECT * FROM j_nems_deadline WHERE com_id = '$_SESSION[id]' AND post_id='$_SESSION[post_id]' AND status=''";
		$result5 = mysqli_query($conn, $sql5) or die(mysqli_error());
		if (mysqli_num_rows($result5) == 1) {
			exit('unauthorised access');
		}
		
		
		

if($num_attempt == "Just once"){
	$sql2 = "SELECT * FROM j_nems_result_list WHERE test_id = '$_SESSION[post_id]' AND student_id='$_SESSION[student_id]'";
		$result2 = mysqli_query($conn, $sql2) or die(mysqli_error());
		if (mysqli_num_rows($result2) > 0) {
			//include("../banner_login.php");
			print "
			<link href=\"../images/style.css\" rel=\"stylesheet\" type=\"text/css\" />
			
			<p align=\"center\">
			<br /><br /><br />
				<b><font color=\"red\">Sorry this test is to be taken once AND 
				record shows that you have taken it once already!</font></b>
				<br />
				<a href=\"home_student.php\">CLICK HERE to Return</a>
			</p>			
			";
			exit();
		}
}		
?>
<!-- ===================================================================== -->
<script language="JavaScript" type="text/javascript" src="../images/script.js"></script>
<link href="../images/style.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	background-color: #FFFFFF;
}
.style1 {font-size: 16pt}
.style2 {
	font-size: 24pt;
	color: #7598B4;
}
-->



.fixed-content {
    top: 0;
    bottom:0;
    position:fixed;
    
    width: 300px;
    height: 100px;
    
    top: 20%;
    left: 80%;
    margin-top: -50px;
    margin-left: -50px;
}
</style>

<style type="text/css">
<!-- @import "../_stud - Copy/css/jquery.countdown.css"; -->
#defaultCountdown { width: 240px; height: 45px; }
</style>
<!-- =========================================================================== -->



<div class="page-content">
    	<div class="row">
		  
		  <div class="col-md-12">
          
          
           <div class="content-box-large">
			  <div class="panel-heading">
					<div class="panel-title">
					
					<?php
					if($_SESSION['user_type']=='applicant'){
						print '<a href="../../../apply_student_home.php">Go Back</a>';
					}else{
						print '<a href="home_student.php">Go Back</a>';
					}
					?>
					
					<h2><?php print "$post_name"; ?></h2>
					</div>
		</div>
  				<div class="panel-body">
				
<?php
if($_SESSION['user_type']=='applicant'){
	print '<form id="form1" name="form1" method="post" action="applicant_student_test_start_complete.php">';
}else{
	print '<form id="form1" name="form1" method="post" action="student_test_start_complete.php">';
}
?>

				
				<?php
$sql2 = "SELECT * FROM j_nems_question  WHERE test_id='$_SESSION[post_id]'";
$result2 = mysqli_query($conn, $sql2) or die(mysqli_error());
$num_row = mysqli_num_rows($result2);


$sql = "SELECT * FROM j_nems_question WHERE test_id='$_SESSION[post_id]' 
 ORDER BY rand() limit 0,$num_row";
$result = mysqli_query($conn, $sql) or die(mysqli_error());

//get the number of rows in the result set; should be 1 if a match

print "

<table class=\"table table-hover\">

";



$counter = 0;

while($info = mysqli_fetch_array($result))

	{

    //print "<pre>";

    //var_dump($info);

    //exit;

	$counter = $counter + 1;

	//if authorized, get the values of f_name n l_name	

	

		 $id=$info['id'];		 

		 $question=$info['question'];

$question=stripslashes($question);

		 $optionA=$info['optionA'];



		 $optionA_detail=$info['optionA_detail'];

$optionA_detail=stripslashes($optionA_detail);



		 $optionB=$info['optionB'];

		 $optionB_detail=$info['optionB_detail'];

$optionB_detail=stripslashes($optionB_detail);



		 $optionC=$info['optionC'];

		 $optionC_detail=$info['optionC_detail'];

$optionC_detail=stripslashes($optionC_detail);



		 $optionD=$info['optionD'];

		 $optionD_detail=$info['optionD_detail'];

$optionD_detail=stripslashes($optionD_detail);



		 $correct_option=$info['correct_option'];

		 

//----------------IMAGE PROCESS------------

		 $question_img=$info['question_img'];

		 $optionA_img=$info['optionA_img'];

		 $optionB_img=$info['optionB_img'];

		 $optionC_img=$info['optionC_img'];

		 $optionD_img=$info['optionD_img'];

		 $ans_img=$info['ans_img'];

		 

     $im1=$im2=$im3=$im4=$im5=$im6="";
     
    	 //get the additional data for explain question....
		 $question_img_pix="";
		 $question_explain_text="";
		 	$sql2 = "SELECT * FROM nems_message WHERE school_id = '$_SESSION[id]' AND date_sent='$id'";
			$result2 = mysqli_query($conn, $sql2) or die(mysqli_error($conn)); 
			if (mysqli_num_rows($result2) > 0) {
				$info2 = mysqli_fetch_array($result2);
					$question_id=$info2['date_sent'];
					$question_explain_img=$info2['msg_subject'];
					$question_explain_text=$info2['msg_detail'];
					
					if($question_explain_img != ""){
						$question_img_pix="<img src=\"../_tuto_test/piks/$question_explain_img\" width=\"50%\">";
					}	
			}

if($question_img != ""){

	$im1="<img src=\"../_tuto_test/piks/$question_img\" width=\"50%\">";

}

if($optionA_img != ""){

	$im2="<img src=\"../_tuto_test/piks/$optionA_img\" width=\"50%\">";

}

if($optionB_img != ""){

	$im3="<img src=\"../_tuto_test/piks/$optionB_img\" width=\"50%\">";

}

if($optionC_img != ""){

	$im4="<img src=\"../_tuto_test/piks/$optionC_img\" width=\"50%\">";

}

if($optionD_img != ""){

	$im5="<img src=\"../_tuto_test/piks/$optionD_img\" width=\"50%\">";

}

if($ans_img != ""){

	$im6="<img src=\"../_tuto_test/piks/$ans_img\" width=\"50%\">";

}



//---------------------------------------------------

		 

	

	print "	

<tr>

<td>

<b> $counter. $question </b>
$question_explain_text
$question_img_pix
<br />

$im1

<br /><br />

A. <input name=\"$id\" type=\"radio\" value=\"A\" /> $optionA_detail

<br />

$im2

<br />

B. <input name=\"$id\" type=\"radio\" value=\"B\" /> $optionB_detail

<br />

$im3

<br />

C. <input name=\"$id\" type=\"radio\" value=\"C\" /> $optionC_detail

<br />

$im4

<br />

D. <input name=\"$id\" type=\"radio\" value=\"D\" /> $optionD_detail

<br />

$im5

<br /><br />

</td>

</tr>

		

	

	";

	



	$_SESSION['num_of_question']=$counter;

	

	// store the id in and array

	//$id_arr[] = $id;

	$_SESSION['selected_options'][$id] = $info;

}





print "</table>";	

		

		?>


                      <input name="test_id" type="hidden" id="test_id" value="<?php print $_GET['id'] ?>" />
                    
                    <input type="submit" name="Submit" value="                SUBMIT                 " />
                  </form>		


				  
				  <div class="fixed-content"><strong>Timer: </strong> <span id="countdown" class="timer"></span></div>
                      <script>
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
function Redirect()
{
    //window.location="http://www.bengallery.net";
	document.getElementById("form1").submit();
}

var seconds = <?php print $timer; ?>;
function secondPassed() {
    var minutes = Math.round((seconds - 30)/60);
    var remainingSeconds = seconds % 60;
    if (remainingSeconds < 10) {
        remainingSeconds = "0" + remainingSeconds; 
    }
    document.getElementById('countdown').innerHTML = "<font color=blue size=5><b>"+minutes + ":" + remainingSeconds+"</b></font>";
    if (seconds == 0) {
        clearInterval(countdownTimer);
        document.getElementById('countdown').innerHTML = "<font color=red size=5><b>TIME UP</b></font><font color=red> Please submit: else you will be logout automatically in the next few seconds</font>";
				
		//------------ SENT OUT AFTER 10 SEC. -----------
		setTimeout('Redirect()', 8000);


    } else {
        seconds--;
    }
}
 
var countdownTimer = setInterval('secondPassed()', 1000);
                </script>
				
</div>
</div>
</div>
</div>
</div>




  <?php include("../footer.php"); ?>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://code.jquery.com/jquery.js"></script>
    <!-- jQuery UI -->
    <script src="https://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="../bootstrap/js/bootstrap.min.js"></script>

    <link rel="stylesheet" href="../vendors/morris/morris.css">


    <script src="../vendors/jquery.knob.js"></script>
    <script src="../vendors/raphael-min.js"></script>
    <script src="../vendors/morris/morris.min.js"></script>

    <script src="../vendors/flot/jquery.flot.js"></script>
    <script src="../vendors/flot/jquery.flot.categories.js"></script>
    <script src="../vendors/flot/jquery.flot.pie.js"></script>
    <script src="../vendors/flot/jquery.flot.time.js"></script>
    <script src="../vendors/flot/jquery.flot.stack.js"></script>
    <script src="../vendors/flot/jquery.flot.resize.js"></script>

    <script src="../js/custom.js"></script>
    <script src="../js/stats.js"></script>
  </body>
</html>