<?php 
include("banner1.php");

/*
$student_id = $_SESSION['student_id'];

$query  = "SELECT * FROM nems_student WHERE student_id ='$student_id'";

$result = mysqli_query($conn, $query) or die(mysqli_error());
$info = mysqli_fetch_array($result);

$piks = $info['piks'];
$student_id = $info['student_id'];
$reg_go=$info['reg_no'];		
$student_first_name=$info['first_name'];
$student_other_name=$info['other_name'];
$student_sex=$info['sex'];
$student_DOB=$info['DOB'];
$student_contact_address=$info['contact_address'];
$student_phone=$info['phone_number'];
$student_state_of_origin=$info['state_of_origin'];
$student_admission=$info['admission_date'];
$nationality=$info['nationality'];
$class_subject=$info['class_subject'];
$adm_month=$info['adm_month'];
$fees_paid=$info['fees_paid'];
$med_record=$info['med_record'];
$more_comment=$info['more_comment'];
$result_status=$info['adm_month'];

$class = $class_subject;
include("../_sch/inc_class.php");

if($piks==""){
	$piks = "";
}else{
	$piks = "<img src=\"../_sch/piks/$piks\" width=200>";
}
*/
?>



	
<?php //include("navigation_student.php"); ?>	

<div class="page-content">





    	<div class="row">
		  
		  <div class="col-md-12">
          
          
           <div class="content-box-large">
			  <div class="panel-heading">
					<div class="panel-title">
<?php

if($_SESSION['s_n']==""){ //test only student
	print '<a href="student_test_result.php"><b>Test Results</b></a>';
}else{ //student is assigned to school

		$sql2 = "SELECT * FROM j_nems_result_list WHERE student_id='$_SESSION[student_id]'";
		$result2 = mysqli_query($conn, $sql2) or die(mysqli_error());
		$num_done = mysqli_num_rows($result2);
		
		
	print '<a href="student_test_result.php"><b>'.$num_done.' Test Results</b></a> | <b><a href="student_pending_test.php">	';
	
	$sql = "SELECT * FROM nems_test_mgt WHERE student_id = '$_SESSION[student_id]' AND test_status=''";
$result = mysqli_query($conn, $sql) or die(mysqli_error());
print mysqli_num_rows($result);
    print ' Test Pending Approval </a></b>';
}

//print $_SESSION['s_n'];
?>
	


 


					<h2>Take Test</h2>
                    </div>		


 
			  </div>
  				<div class="panel-body">
				


	
			

<form id="form1" name="form1" method="post" action="">
 <div class="form-group">
	<label class="col-sm-3 control-label">Enter subject</label>
    <div class="col-sm-7">
		<input name="test_search" type="text" id="test_search" class="form-control" />
	</div>	
	<label class="col-sm-2 control-label">
	 <button type="submit" class="btn btn-primary">Search</button>
	</label>
</div>

</form>

<br/><br/><br/><br/>
<?php


// how many rows to show per page
$rowsPerPage = 10;

// by default we show first page
$pageNum = 1;

// if $_GET['page'] defined, use it as page number
if(isset($_GET['page']))
{
	$pageNum = $_GET['page'];
}

// counting the offset
$offset = ($pageNum - 1) * $rowsPerPage;


if(isset($_POST['test_search'])){
	$search_key = $_POST['test_search'];
	print "<b><font color=\"blue\">Search for: $search_key</font></b><br />";
	//$query = "SELECT * FROM j_nems_post WHERE com_id= '$_SESSION[id]' AND (test_type='$_SESSION[class_subject]' OR test_type='open') AND post_name LIKE'%$search_key%' OR num_attempt LIKE'%$search_key%'";
	
	$query = "SELECT * FROM j_nems_post WHERE test_type='open' AND post_name LIKE'%$search_key%' OR num_attempt LIKE'%$search_key%'";
	
	
}else{

	$query = "SELECT * FROM j_nems_post WHERE test_type='open' ORDER BY id DESC LIMIT $offset, $rowsPerPage";
}		
		
print "
<table class=\"table table-hover\">
<tr>
<th>Subject</th>
<th>Ouestion</th>
<th>Status</th>
<th></th>
</tr>
";	

	
$result = mysqli_query($conn, $query);

if(!$result){
	printf("Error: %s\n",mysqli_error($conn));
	exit();
}

	while($select_class2 = mysqli_fetch_array($result)) {
		$c_id = $select_class2['id'];
		$post_name = $select_class2['post_name'];
		$detail = substr($select_class2['detail'], 0, 300);
		$test_type = $select_class2['test_type'];
		$num_attempt = $select_class2['num_attempt'];
		$poster_id = $select_class2['com_id'];
		
			
		
		//Get total num of question set
		$sql1 = "SELECT * FROM j_nems_question WHERE test_id='$c_id'";
		$result1 = mysqli_query($conn, $sql1);		
		$num_questions = mysqli_num_rows($result1);	
		
		
		if($num_attempt == "Just once"){
			$sql2 = "SELECT * FROM j_nems_result_list WHERE test_id = '$c_id' AND student_id='$_SESSION[student_id]'";
				$result2 = mysqli_query($conn, $sql2) or die(mysqli_error());
				if (mysqli_num_rows($result2) > 0) {					
					$btn = "<a href=\"#\"><button type=\"submit\" class=\"btn btn-warning\">Test Done</button></a>";				
				}else{
					$btn = "<a href=\"student_test_welcome.php?pid=$c_id&tut=$poster_id\"><button type=\"submit\" class=\"btn btn-primary\">Take Test</button></a>";
				}
		}else{
			$btn = "<a href=\"student_test_welcome.php?pid=$c_id&tut=$poster_id\"><button type=\"submit\" class=\"btn btn-primary\">Take Test</button></a>";
		}


				 		
				print "
				
				<tr>
<td><b><a href=\"student_test_welcome.php?pid=$c_id&tut=$poster_id\">".$post_name."</a></b></td>
<td>$num_questions</td>
<td>$test_type ($num_attempt)</td>
<td>$btn</td>
</tr>		
					";
	}
			

print "</table>";


if(!$_POST['test_search']){
// how many rows we have in database
$query   = "SELECT COUNT(id) AS numrows FROM j_nems_post WHERE com_id= '$_SESSION[id]' AND (test_type='$_SESSION[class_subject]' OR test_type='open')";
$result  = mysqli_query($conn, $query);
$row     = mysqli_fetch_array($result);
$numrows = $row['numrows'];


// how many pages we have when using paging?
$maxPage = ceil($numrows/$rowsPerPage);

// print the link to access each page
$self = $_SERVER['PHP_SELF'];
$nav = '';
for($page = 1; $page <= $maxPage; $page++)
{
	if ($page == $pageNum)
	{
		$nav .= " $page ";   // no need to create a link to current page
	}
	else
	{
		$nav .= " <a href=\"$self?page=$page\">$page</a> ";
	}		
}

// creating previous and next link
// plus the link to go straight to
// the first and last page

if ($pageNum > 1)
{
	$page = $pageNum - 1;
	$prev = " <a href=\"$self?page=$page\">[Prev]</a> ";
	
	$first = " <a href=\"$self?page=1\"> [First Page]</a> ";
} 
else
{
	$prev  = '&nbsp;'; // we're on page one, don't print previous link
	$first = '&nbsp;'; // nor the first page link
}

if ($pageNum < $maxPage)
{
	$page = $pageNum + 1;
	$next = " <a href=\"$self?page=$page\">[Next]</a> ";	
	$last = " <a href=\"$self?page=$maxPage\">[Last Page]</a> ";
} 
else
{
	$next = '&nbsp;'; // we're on the last page, don't print next link
	$last = '&nbsp;'; // nor the last page link
}

// print the navigation link
print $first . $prev . $nav . $next . $last;
}
?>

</div>
</div>
</div>
</div>




  <?php include("../footer.php"); ?>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://code.jquery.com/jquery.js"></script>
    <!-- jQuery UI -->
    <script src="https://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="../bootstrap/js/bootstrap.min.js"></script>

    <link rel="stylesheet" href="../vendors/morris/morris.css">


    <script src="../vendors/jquery.knob.js"></script>
    <script src="../vendors/raphael-min.js"></script>
    <script src="../vendors/morris/morris.min.js"></script>

    <script src="../vendors/flot/jquery.flot.js"></script>
    <script src="../vendors/flot/jquery.flot.categories.js"></script>
    <script src="../vendors/flot/jquery.flot.pie.js"></script>
    <script src="../vendors/flot/jquery.flot.time.js"></script>
    <script src="../vendors/flot/jquery.flot.stack.js"></script>
    <script src="../vendors/flot/jquery.flot.resize.js"></script>

    <script src="../js/custom.js"></script>
    <script src="../js/stats.js"></script>
  </body>
</html>