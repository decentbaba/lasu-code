<?php 
session_start();

if (!$_SESSION['student_id']){
	print "
	
	<p>
	Sorry your session has ended</font></b></p>
         <a href=\"../index.php\">Click here</a> and  Login again.";
	exit;
	}
include("../../conn.php");	

if(isset($_GET['pid'])){
	$test_id = mysqli_escape_string($conn, $_GET['pid']);
	$_SESSION['post_id']=$test_id;
	$tut = mysqli_escape_string($conn, $_GET['tut']);
}


$sql2 = "SELECT * FROM j_nems_post WHERE id = '$_SESSION[post_id]'";
		$result2 = mysqli_query($conn, $sql2) or die(mysqli_error());
		$rec = mysqli_fetch_array($result2);		
		$post_name = $rec['post_name'];
		$num_attempt = $rec['num_attempt'];
		$test_type = $rec['test_type'];


if($test_type == "close"){
	$sql2 = "SELECT * FROM nems_test_mgt WHERE (student_id = '$_SESSION[student_id]' AND test_id='$_SESSION[post_id]')";
	
	
		$result2 = mysqli_query($conn, $sql2) or die(mysqli_error());
		$rec = mysqli_fetch_array($result2);		
			$test_status = $rec['test_status'];
			
		
		if(mysqli_num_rows($result2) == 0){
			//-----------------------------------------
			$date_approve=date('d-m-Y');
			$sql="INSERT INTO nems_test_mgt VALUES (DEFAULT,'', '$tut',
			 '$_SESSION[post_id]','$_SESSION[student_id]','$date_approve','','')"; 
				mysqli_query($conn, $sql) or die(mysqli_error());
			
			include("../banner_login.php");
			print "
			<link href=\"../images/style.css\" rel=\"stylesheet\" type=\"text/css\" />
			
			<p align=\"center\">
			<br /><br /><br />
				<b><font color=\"blue\">You have just applied to take this closed test, 
				please wait for the approval from your instructor (i.e. the author of the test) Thank you.!</font></b>
				<br />
				<a href=\"student_test.php\">CLICK HERE to Return</a>
			</p>	
			
			";
			exit();
		}elseif($test_status == ''){
			//include("../banner_login.php");
			print "
			<link href=\"../images/style.css\" rel=\"stylesheet\" type=\"text/css\" />
			
			<p align=\"center\">
			<br /><br /><br />
				<b><font color=\"red\">You have already applied to take this test, please wait for your approval!</font></b>
				<br />
				<!--<a href=\"student_test.php\">CLICK HERE to Return</a>-->
				<a href=\"home_student.php\">CLICK HERE to Return</a>
				
			</p>
					
			";
			exit();
			
		}elseif($test_status == '1'){
			header("Location:student_test_welcome1.php");	
		}else{
			//-----------------------------------------
			//print "Problem here";
			//-----------------------------------------
			$date_approve=date('d-m-Y');
			$sql="INSERT INTO nems_test_mgt VALUES (DEFAULT,'', '$tut',
			 '$_SESSION[post_id]','$_SESSION[student_id]','$date_approve','','')"; 
				mysqli_query($conn, $sql) or die(mysqli_error());
			
			include("../banner_login.php");
			print "
			<link href=\"../images/style.css\" rel=\"stylesheet\" type=\"text/css\" />
			
			<p align=\"center\">
			<br /><br /><br />
				<b><font color=\"blue\">You have just applied to take this closed test, 
				please wait for the approval from your instructor (i.e. the author of the test) Thank you.!</font></b>
				<br />
				<a href=\"student_test.php\">CLICK HERE to Return</a>
			</p>	
			";
			exit();
			
		}
		
		
		//Then is status is equal to 1, then he has been approved
}elseif($test_type == "open"){
	header("Location:student_test_welcome1.php");	
}

if($_SESSION['user_type']=='applicant'){
	header("Location:student_test_welcome1.php");	
}
?>