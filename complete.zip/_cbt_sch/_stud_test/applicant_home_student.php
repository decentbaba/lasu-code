<?php 
include("applicant_banner1.php");

$student_id = $_SESSION['student_id'];

$query  = "SELECT * FROM nems_student_apply WHERE 
student_id ='$student_id'";

$result = mysqli_query($conn, $query) or die(mysqli_error());
$info = mysqli_fetch_array($result);
$class_subject=$info['class_subject'];
$status=$info['status'];

$class = $class_subject;
$sql_class  = "SELECT * FROM nems_class 
WHERE class_id='$class'";
$result_class = mysqli_query($conn, $sql_class) or die(mysqli_error());
$info_class = mysqli_fetch_array($result_class);
	$class_name =$info_class['name'];


?>



	
<?php //include("navigation_student.php"); ?>	

<div class="page-content">
    	<div class="row">
		  
		  <div class="col-md-12">
          
          
           <div class="content-box-large">
			  <div class="panel-heading">
					<div class="panel-title">
					<a href="../../../apply_student_home.php">Go Back</a> 
 
 
					<h2>Take Test</h2>
                    </div>		


 
			  </div>
  				<div class="panel-body">
				

<?php

//if($status != '1'){
//	print "Sorry, you cannot take this test!";
//}else{

			$query = "SELECT * FROM j_nems_post WHERE test_type = 'applicant' ORDER BY id DESC ";		
			print "
			<table class=\"table table-hover\">
			<tr>
			<th>Subject</th>
			<th>Ouestion</th>
			<th>Status</th>
			<th></th>
			</tr>
			";	
//print $status;
				
			$result = mysqli_query($conn, $query);

			if(!$result){
				printf("Error: %s\n",mysqli_error($conn));
				exit();
			}

				while($select_class2 = mysqli_fetch_array($result)) {
					$c_id = $select_class2['id'];
					$post_name = $select_class2['post_name'];
					$detail = substr($select_class2['detail'], 0, 300);
					$test_type = $select_class2['test_type'];
					$num_attempt = $select_class2['num_attempt'];
					$poster_id = $select_class2['com_id'];
					
						
					
					//Get total num of question set
					$sql1 = "SELECT * FROM j_nems_question WHERE test_id='$c_id'";
					$result1 = mysqli_query($conn, $sql1);		
					$num_questions = mysqli_num_rows($result1);	
					
					
					//Check if student have table the test
					$sql2 = "SELECT * FROM j_nems_result_list WHERE test_id='$c_id' AND student_id='$student_id' AND test_name='applicant'";
					$result2 = mysqli_query($conn, $sql2);		
					if(mysqli_num_rows($result2)==1){
						$data = mysqli_fetch_array($result2);
						$batch_num = $data['batch_num'];
						
						$button = "<a href=\"student_test_result_detail.php?bat=$batch_num\"><button type=\"submit\" class=\"btn btn-warning\">Test Result</button></a>";
					}else{
						$button = "<a href=\"student_test_welcome.php?pid=$c_id&tut=$poster_id\"><button type=\"submit\" class=\"btn btn-primary\">Take Test</button></a>";
					}
					 
									
							print "
							
							<tr>
			<td><b>$post_name</b></td>
			<td>$num_questions</td>
			<td>$test_type ($num_attempt)</td>
			<td>$button</td>
			</tr>		
								";
				}
						

			print "</table>";
//}

?>

</div>
</div>
</div>
</div>




  <?php include("../footer.php"); ?>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://code.jquery.com/jquery.js"></script>
    <!-- jQuery UI -->
    <script src="https://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="../bootstrap/js/bootstrap.min.js"></script>

    <link rel="stylesheet" href="../vendors/morris/morris.css">


    <script src="../vendors/jquery.knob.js"></script>
    <script src="../vendors/raphael-min.js"></script>
    <script src="../vendors/morris/morris.min.js"></script>

    <script src="../vendors/flot/jquery.flot.js"></script>
    <script src="../vendors/flot/jquery.flot.categories.js"></script>
    <script src="../vendors/flot/jquery.flot.pie.js"></script>
    <script src="../vendors/flot/jquery.flot.time.js"></script>
    <script src="../vendors/flot/jquery.flot.stack.js"></script>
    <script src="../vendors/flot/jquery.flot.resize.js"></script>

    <script src="../js/custom.js"></script>
    <script src="../js/stats.js"></script>
  </body>
</html>