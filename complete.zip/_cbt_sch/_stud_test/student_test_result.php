<?php 
include("banner1.php");

if(isset($_REQUEST['del'])){
	
	$bat = mysqli_escape_string($conn, $_REQUEST['bat']);
	$test_id = mysqli_escape_string($conn, $_REQUEST['test_id']);
	
	$query1  = "DELETE FROM j_nems_result WHERE batch_num_val = '$bat'";
	mysqli_query($conn, $query1) or die($conn);
	
	$query2  = "DELETE FROM j_nems_result_list WHERE batch_num = '$bat'";
	mysqli_query($conn, $query2) or die($conn);


}


?>
<!-- ===================================================================== -->
<script language="JavaScript" type="text/javascript" src="../images/script.js"></script>
<link href="../images/style.css" rel="stylesheet" type="text/css" />

<!-- =========================================================================== -->



<div class="page-content">
    	<div class="row">
		  
		  <div class="col-md-12">
          
          
           <div class="content-box-large">
			  <div class="panel-heading">
					<div class="panel-title">
					
					<?php
					if(isset($_SESSION['full_name'])){
						print "
						<h2><b>$_SESSION[full_name]</b> Test Result</h2>
						";
					}else{
						
						print "
						<h2>Test Result</h2>
						<a href=\"home_student.php\">Go Back</a>
						";						
					}
					?>
					
					
					
					</div>
		</div>
  				<div class="panel-body">
				


<?php
$rowsPerPage = 10;

// by default we show first page
$pageNum = 1;

// if $_GET['page'] defined, use it as page number
if(isset($_GET['page']))
{
	$pageNum = $_GET['page'];
}

// counting the offset
$offset = ($pageNum - 1) * $rowsPerPage;


$sql = "SELECT * FROM j_nems_result_list WHERE student_id = '$_SESSION[student_id]'";
$pagingQuery = "ORDER BY id DESC LIMIT $offset, $rowsPerPage";
$result = mysqli_query($conn, $sql . $pagingQuery) or die(mysqli_error());

	
	print "<table class=\"table table-hover\">
	<tr>
		<th><b>Date/Time Taken</b></th>
		<th><b>Test Title</b></th>		
		<th><b>Result</b></th>
		<th></th>
	</tr>
	";
	
	while($rec = mysqli_fetch_array($result)){			
							
				$id = $rec['id'];	
				$test_id = $rec['test_id'];
				$date_taken = $rec['date_taken'];
				$batch_num = $rec['batch_num'];
				
							
						$sql2 = "SELECT * FROM j_nems_post WHERE id = '$test_id'";
						$result2= mysqli_query($conn, $sql2) or die(mysqli_error());
						$data = mysqli_fetch_array($result2);						
							$post_name = $data['post_name'];
							$test_type = $data['test_type'];
							$num_attempt = $data['num_attempt'];
						
				
								print "
								<tr>	
									<td>$date_taken</td>							
									<td>$post_name</td>																									
									<td><a href=\"student_test_result_detail.php?bat=$batch_num&test_id=$test_id \">Result Detail</a></td> 
									<td><a href=\"student_test_result.php?bat=$batch_num&test_id=$test_id&del=1 \">Delete</a></td> 
								</tr>														
								";
	}

print "</table>";


// how many rows we have in database
$result  = mysqli_query($conn, $sql) or die('Error, query failed');
$numrows = mysqli_num_rows($result);

// how many pages we have when using paging?
$maxPage = ceil($numrows/$rowsPerPage);

$self = $_SERVER['PHP_SELF'];

// creating 'previous' and 'next' link
// plus 'first page' and 'last page' link

// print 'previous' link only if we're not
// on page one
if ($pageNum > 1)
{
	$page = $pageNum - 1;
	$prev = " <a href=\"$self?page=$page&id=$_GET[id]\">[Prev]</a> ";

	$first = " <a href=\"$self?page=1&id=$_GET[id]\">[First Page]</a> ";
}
else
{
	$prev  = ' [Prev] ';       // we're on page one, don't enable 'previous' link
	$first = ' [First Page] '; // nor 'first page' link
}

// print 'next' link only if we're not
// on the last page
if ($pageNum < $maxPage)
{
	$page = $pageNum + 1;
	$next = " <a href=\"$self?page=$page&id=$_GET[id]\">[Next]</a> ";

	$last = " <a href=\"$self?page=$maxPage&id =$_GET[id]\">[Last Page]</a> ";
}
else
{
	$next = ' [Next] ';      // we're on the last page, don't enable 'next' link
	$last = ' [Last Page] '; // nor 'last page' link
}

// print the page navigation link
echo $first . $prev . " Showing page <strong>$pageNum</strong> of <strong>$maxPage</strong> pages " . $next . $last;

if ($maxPage == 0) {
print "<p><B>SORRY</B> No record";
}
?>
   
				
</div>
</div>
</div>
</div>
</div>




  <?php include("../footer.php"); ?>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://code.jquery.com/jquery.js"></script>
    <!-- jQuery UI -->
    <script src="https://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="../bootstrap/js/bootstrap.min.js"></script>

    <link rel="stylesheet" href="../vendors/morris/morris.css">


    <script src="../vendors/jquery.knob.js"></script>
    <script src="../vendors/raphael-min.js"></script>
    <script src="../vendors/morris/morris.min.js"></script>

    <script src="../vendors/flot/jquery.flot.js"></script>
    <script src="../vendors/flot/jquery.flot.categories.js"></script>
    <script src="../vendors/flot/jquery.flot.pie.js"></script>
    <script src="../vendors/flot/jquery.flot.time.js"></script>
    <script src="../vendors/flot/jquery.flot.stack.js"></script>
    <script src="../vendors/flot/jquery.flot.resize.js"></script>

    <script src="../js/custom.js"></script>
    <script src="../js/stats.js"></script>
  </body>
</html>