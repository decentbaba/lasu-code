<?php 
session_start();
if($_SESSION['user_type']=='applicant'){
	include("applicant_banner1.php");
}else{
	include("banner1.php");
}

if(isset($_GET['pid'])){
	$test_id = mysqli_escape_string($conn, $_GET['pid']);
	$_SESSION['post_id']=$test_id;
	$tut = mysqli_escape_string($conn, $_GET['tut']);
}


$sql2 = "SELECT * FROM j_nems_post WHERE id = '$_SESSION[post_id]'";
		$result2 = mysqli_query($conn, $sql2) or die(mysqli_error());
		$rec = mysqli_fetch_array($result2);		
		$post_name = $rec['post_name'];
		$num_attempt = $rec['num_attempt'];
		$test_type = $rec['test_type'];
?>



	
<?php //include("navigation_student.php"); ?>	

<div class="page-content">
    	<div class="row">
		  
		  <div class="col-md-12">
          
          
           <div class="content-box-large">
			  <div class="panel-heading">
					<div class="panel-title">
					<?php
					if($_SESSION['user_type']=='applicant'){
						print '<a href="../../../apply_student_home.php">Go Back</a>';
					}else{
						print '<a href="home_student.php">Go Back</a>';
					}
					?>
					
					<h2>Test Instruction</h2>
					</div>
		</div>
  				<div class="panel-body">
				

<?php			
 
$sql = "SELECT * FROM j_nems_instruction WHERE post_id = '$_SESSION[post_id]' ORDER BY id DESC";
$result = mysqli_query($conn, $sql) or die(mysqli_error());

//get the number of rows in the result set; should be 1 if a matchs
if (mysqli_num_rows($result) != 0) {

	//if authorized, get the values of f_name n l_name\
	$info = mysqli_fetch_array($result);
		$g_id = $info['id'];	
		$post_id = $info['post_id'];	
		$content = $info['instruction'];
	
	//print $_SESSION['post_id']; 
	
		// Select the NAME of the TEST
		$sql2 = "SELECT * FROM j_nems_post WHERE id = '$_SESSION[post_id]'";
		$result2 = mysqli_query($conn, $sql2) or die(mysqli_error());
		$rec = mysqli_fetch_array($result2);		
		$post_name = $rec['post_name'];	
		$test_type = $rec['test_type'];	
			
		$_SESSION['company_id'] = $rec['com_id'];
		
	  $content3 = stripslashes($content);
	  print "<h3>$post_name</h3> 
	  <font size=3>$content3</font>";


			print "
			
					<form id=\"form1\" name=\"form1\" method=\"post\" action=\"student_test_start.php\">					 
					   			<br/>				
								<input name=\"txt_status\" type=\"checkbox\" id=\"txt_status\" value=\"1\"  checked=\"checked\" class=\"form-control\" />
								<br/>
								<p align='center'>							
								<button type=\"submit\" class=\"btn btn-primary\">I AGREE, START NOW</button>
								</p>							
					</form>
	  		";
	}
		  
	
?>
	


</div>
</div>
</div>
</div>
</div>




  <?php include("../footer.php"); ?>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://code.jquery.com/jquery.js"></script>
    <!-- jQuery UI -->
    <script src="https://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="../bootstrap/js/bootstrap.min.js"></script>

    <link rel="stylesheet" href="../vendors/morris/morris.css">


    <script src="../vendors/jquery.knob.js"></script>
    <script src="../vendors/raphael-min.js"></script>
    <script src="../vendors/morris/morris.min.js"></script>

    <script src="../vendors/flot/jquery.flot.js"></script>
    <script src="../vendors/flot/jquery.flot.categories.js"></script>
    <script src="../vendors/flot/jquery.flot.pie.js"></script>
    <script src="../vendors/flot/jquery.flot.time.js"></script>
    <script src="../vendors/flot/jquery.flot.stack.js"></script>
    <script src="../vendors/flot/jquery.flot.resize.js"></script>

    <script src="../js/custom.js"></script>
    <script src="../js/stats.js"></script>
  </body>
</html>