<?php 
session_start();

	include("banner1.php");


if(isset($_GET['pid'])){
	$test_id = mysqli_escape_string($conn, $_GET['pid']);
	$_SESSION['post_id']=$test_id;
}

//===========================================================================
$testEndTime = new DateTime;
$testStartTime = $_SESSION['testStartTime'];
$date_taken = date('d-m-Y, h:i:s A');

//=========================== GET THE BATCH NUM =============================
$query77  = "SELECT * FROM j_nems_result_list ORDER BY id DESC";
    $result77 = mysqli_query($conn, $query77) or die(mysqli_error());
	$select77 = mysqli_fetch_array($result77);
	
	if (mysqli_num_rows($result77) == 0) {
		$batch_num_val = 1;
	}else{		
		$batch_num = $select77['batch_num'];
		$batch_num_val = $batch_num + 1;
	}
	
$_SESSION['another_time_end'] = date("h:i A.", time());



?>
<!-- ===================================================================== -->
<script language="JavaScript" type="text/javascript" src="../images/script.js"></script>
<link href="../images/style.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	background-color: #FFFFFF;
}
.style1 {font-size: 16pt}
.style2 {
	font-size: 24pt;
	color: #7598B4;
}
-->
</style>

<style type="text/css">
<!-- @import "../_stud - Copy/css/jquery.countdown.css"; -->
#defaultCountdown { width: 240px; height: 45px; }
</style>
<!-- =========================================================================== -->



<div class="page-content">
    	<div class="row">
		  
		  <div class="col-md-12">
          
          
           <div class="content-box-large">
			  <div class="panel-heading">
					<div class="panel-title">
					<a href="home_student.php">Go Back</a>
					<h2>Test Completed</h2>
					</div>
		</div>
  				<div class="panel-body">
				

<?php

$sql2 = "SELECT * FROM j_nems_question  WHERE com_id='$_SESSION[company_id]' AND test_id='$_SESSION[post_id]'";
$result2 = mysqli_query($conn, $sql2) or die(mysqli_error());
$num_row = mysqli_num_rows($result2);


$counter = 0;
$correct = 0;
$wrong = 0;
//-----------------------
//$userAnswer='';
//$questionId ='';
//-------------------------

$QuestionsAttempted = $_POST;
$totalQuestions = count($_SESSION['selected_options']);
$totalQuestionsAttempted = count($QuestionsAttempted);
$totalQuestionsAttempted -= 2; //This Removes the unnecessay Sumbit and test_id count.
//print_r($QuestionsAttempted);exit;



//while($info = mysqli_fetch_array($result2)){
//	$counter++;
	
			
		//}
		
		
		foreach ($QuestionsAttempted as $questionId => $userAnswer) {
			$counter = $counter + 1;
			
		
		    //if(array_key_exists($questionId, $_SESSION['selected_options'])){
		    
			if(isset($questionId, $_SESSION['selected_options'])){
			
	            ///////////////// UPDATE RESULT/////////////////
            		$quest_id = $_SESSION['selected_options'][$questionId]['id'];	
            		
            		
		
				$correct_option = $_SESSION['selected_options'][$questionId]['correct_option'];
				//echo "<pre>";
				//var_dump($_SESSION['selected_options'][$questionId]);
				//exit();
				$question = $_SESSION['selected_options'][$questionId]['question'];
				$question_img = $_SESSION['selected_options'][$questionId]['question_img'];
				$question_img = empty($question_img) ? "" : "<img src=\"admin/piks/$question_img\" />";
				
				if($correct_option=="A"){
					$ans = $_SESSION['selected_options'][$questionId]['optionA_detail'];
					$ans_img = $_SESSION['selected_options'][$questionId]['optionA_img'];
				}elseif($correct_option=="B"){ 
					$ans = $_SESSION['selected_options'][$questionId]['optionB_detail'];
					$ans_img = $_SESSION['selected_options'][$questionId]['optionB_img'];
				}elseif($correct_option=="C"){ 
					$ans = $_SESSION['selected_options'][$questionId]['optionC_detail'];
					$ans_img = $_SESSION['selected_options'][$questionId]['optionC_img'];
				}elseif($correct_option=="D"){ 
					$ans = $_SESSION['selected_options'][$questionId]['optionD_detail'];
					$ans_img = $_SESSION['selected_options'][$questionId]['optionD_img'];
				}	
		
				$ans_img = empty($ans_img) ? "" : "<img src=\"admin/piks/$ans_img\" />";
				if($userAnswer == "A"){
					$ans2 = $_SESSION['selected_options'][$questionId]['optionA_detail'];
					$ans2_img = $_SESSION['selected_options'][$questionId]['optionA_img'];
				}elseif($userAnswer == "B"){ 
					$ans2 = $_SESSION['selected_options'][$questionId]['optionB_detail'];
					$ans2_img = $_SESSION['selected_options'][$questionId]['optionB_img'];
				}elseif($userAnswer =="C"){ 
					$ans2 = $_SESSION['selected_options'][$questionId]['optionC_detail'];
					$ans2_img = $_SESSION['selected_options'][$questionId]['optionC_img'];
				}elseif($userAnswer =="D"){ 
					$ans2 = $_SESSION['selected_options'][$questionId]['optionD_detail'];
					$ans2_img = $_SESSION['selected_options'][$questionId]['optionD_img'];
				}
		
				$ans2_img = empty($ans2_img) ? "" : "<img src=\"admin/piks/$ans2_img\" />";
		
		
		
	
		
						if(is_numeric($questionId)){
				            		$sql11="INSERT INTO j_nems_result VALUES (DEFAULT,'$_SESSION[student_id]','$questionId',
				            		'$userAnswer', '','$_SESSION[company_id]', '$date_taken', '$batch_num_val')"; 	
				            		mysqli_query($conn, $sql11) or die(mysqli_error());
						}
				            		/////////////////////////////////////////////////////////////////////////////////////////////////////////
						//==========================================================================================================
						
					  
						
            					
			}
}
?>
          
	<?php
	print "<p align='center'><h4>Thank you for completing this test. </hr><br/><a href=\"student_test_result_detail.php?bat=$batch_num_val&test_id=$_SESSION[post_id]\">Click here to see your result</a></p>";


			  $_SESSION['selected_options'] = 0;
			  
  

$complete_result = "
<b> Start time: $_SESSION[another_time_start] </b>
<br />
<b> End time: $_SESSION[another_time_end] </b>
";	
			  
//////////////////////////////////// UPDATE THE DB ///////////////////////////////			  
$sql566 = "UPDATE j_nems_result SET test_summary='$complete_result', batch_num_val='$batch_num_val'
WHERE user_email = '$_SESSION[student_id]' AND date_taken = '$date_taken'";
mysqli_query($conn, $sql566) or die(mysqli_error());



//Change status
$sql9 = "UPDATE nems_test_mgt SET test_status ='2', taken_test_batch_no = '$batch_num_val' 
		WHERE student_id = '$_SESSION[student_id]' AND test_id = '$_SESSION[post_id]'";
mysqli_query($conn, $sql9) or die(mysqli_error());


//============================================== Test Record List ======================================


$sql="INSERT INTO j_nems_result_list VALUES (DEFAULT,'$date_taken','','$_SESSION[post_id]','$_SESSION[student_id]','$batch_num_val')";	
mysqli_query($conn, $sql) or die(mysqli_error());


//=================================== IF TEST SHOULD BE TAKEN ONCE ============================
?>
				
				
</div>
</div>
</div>
</div>
</div>




  <?php include("../footer.php"); ?>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://code.jquery.com/jquery.js"></script>
    <!-- jQuery UI -->
    <script src="https://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="../bootstrap/js/bootstrap.min.js"></script>

    <link rel="stylesheet" href="../vendors/morris/morris.css">


    <script src="../vendors/jquery.knob.js"></script>
    <script src="../vendors/raphael-min.js"></script>
    <script src="../vendors/morris/morris.min.js"></script>

    <script src="../vendors/flot/jquery.flot.js"></script>
    <script src="../vendors/flot/jquery.flot.categories.js"></script>
    <script src="../vendors/flot/jquery.flot.pie.js"></script>
    <script src="../vendors/flot/jquery.flot.time.js"></script>
    <script src="../vendors/flot/jquery.flot.stack.js"></script>
    <script src="../vendors/flot/jquery.flot.resize.js"></script>

    <script src="../js/custom.js"></script>
    <script src="../js/stats.js"></script>
  </body>
</html>