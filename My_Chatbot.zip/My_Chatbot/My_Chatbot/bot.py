import collections
import collections.abc

if not hasattr(collections, 'Hashable'):
    collections.Hashable = collections.abc.Hashable


from chatterbot import ChatBot
from chatterbot.trainers import ListTrainer
from chatterbot.trainers import ChatterBotCorpusTrainer
from chatterbot.response_selection import get_random_response


chatbot = ChatBot(name='Virtual Teacher', read_only = True, responseresponse_selection_method=get_random_response,
                 logic_adapters=[
        {
            'import_path': 'chatterbot.logic.SpecificResponseAdapter',
            'input_text': 'empty',
            'output_text': ''
        },
        {   
            'import_path': 'chatterbot.logic.BestMatch',
            'default_response': 'i honestly have no idea how to respond to that',
            'maximum_similarity_threshold': 0.9
        },
        {
            'import_path': 'chatterbot.logic.MathematicalEvaluation'
        }

    ]
    )


# corpus_trainer = ChatterBotCorpusTrainer(chatbot)
# corpus_trainer.train("chatterbot.corpus.english")

trainer = ChatterBotCorpusTrainer(chatbot)
trainer.train(
    "./asi.yml",
    "./greetings.yml",
   "./health.yml",
    "./profile.yml",
    "./money.yml",
    "./food.yml",
    "./emo.yml",
    "./science.yml",
    "./botprofile.yml",
    "./computers.yml",
    "./convo.yml",
    "./literature.yml",
    "./trivia.yml",
    "./psy.yml"
) ## You can add more training samples here.
